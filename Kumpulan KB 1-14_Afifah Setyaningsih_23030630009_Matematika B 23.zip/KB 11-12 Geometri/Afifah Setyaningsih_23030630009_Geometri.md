﻿# Afifah Setyaningsih_23030630009_Geometri
Nama  : Afifah Setyaningsih


NIM   : 23030630009


Kelas : Matematika B 2023


## .

# Visualisasi dan Perhitungan Geometri dengan EMT

Euler menyediakan beberapa fungsi untuk melakukan visualisasi dan
perhitungan geometri, baik secara numerik maupun analitik (seperti
biasanya tentunya, menggunakan Maxima). Fungsi-fungsi untuk
visualisasi dan perhitungan geometeri tersebut disimpan di dalam file
program "geometry.e", sehingga file tersebut harus dipanggil sebelum
menggunakan fungsi-fungsi atau perintah-perintah untuk geometri.


\>load geometry


    Numerical and symbolic geometry.

## Fungsi-fungsi Geometri

Fungsi-fungsi untuk Menggambar Objek Geometri:


  defaultd:=textheight()*1.5: nilai asli untuk parameter d  
  setPlotrange(x1,x2,y1,y2): menentukan rentang x dan y pada bidang  

koordinat


  setPlotRange(r): pusat bidang koordinat (0,0) dan batas-batas
sumbu-x dan y adalah -r sd r


  plotPoint (P, "P"): menggambar titik P dan diberi label "P"


  plotSegment (A,B, "AB", d): menggambar ruas garis AB, diberi label
"AB" sejauh d


  plotLine (g, "g", d): menggambar garis g diberi label "g" sejauh d


  plotCircle (c,"c",v,d): Menggambar lingkaran c dan diberi label "c"


  plotLabel (label, P, V, d): menuliskan label pada posisi P


Fungsi-fungsi Geometri Analitik (numerik maupun simbolik):


  turn(v, phi): memutar vektor v sejauh phi  
  turnLeft(v):   memutar vektor v ke kiri  
  turnRight(v):  memutar vektor v ke kanan  
  normalize(v): normal vektor v  
  crossProduct(v, w): hasil kali silang vektorv dan w.  
  lineThrough(A, B): garis melalui A dan B, hasilnya [a,b,c] sdh.  

ax+by=c.


  lineWithDirection(A,v): garis melalui A searah vektor v


  getLineDirection(g): vektor arah (gradien) garis g


  getNormal(g): vektor normal (tegak lurus) garis g


  getPointOnLine(g):  titik pada garis g


  perpendicular(A, g):  garis melalui A tegak lurus garis g


  parallel (A, g):  garis melalui A sejajar garis g


  lineIntersection(g, h):  titik potong garis g dan h


  projectToLine(A, g):   proyeksi titik A pada garis g


  distance(A, B):  jarak titik A dan B


  distanceSquared(A, B):  kuadrat jarak A dan B


  quadrance(A, B): kuadrat jarak A dan B


  areaTriangle(A, B, C):  luas segitiga ABC


  computeAngle(A, B, C):   besar sudut &lt;ABC


  angleBisector(A, B, C): garis bagi sudut &lt;ABC


  circleWithCenter (A, r): lingkaran dengan pusat A dan jari-jari r


  getCircleCenter(c):  pusat lingkaran c


  getCircleRadius(c):  jari-jari lingkaran c


  circleThrough(A,B,C):  lingkaran melalui A, B, C


  middlePerpendicular(A, B): titik tengah AB


  lineCircleIntersections(g, c): titik potong garis g dan lingkran c


  circleCircleIntersections (c1, c2):  titik potong lingkaran c1 dan
c2


  planeThrough(A, B, C):  bidang melalui titik A, B, C


Fungsi-fungsi Khusus Untuk Geometri Simbolik:


  getLineEquation (g,x,y): persamaan garis g dinyatakan dalam x dan y  
  getHesseForm (g,x,y,A): bentuk Hesse garis g dinyatakan dalam x dan  

y dengan titik A pada sisi positif (kanan/atas) garis


  quad(A,B): kuadrat jarak AB


  spread(a,b,c): Spread segitiga dengan panjang sisi-sisi a,b,c, yakni
sin(alpha)^2 dengan alpha sudut yang menghadap sisi a.


  crosslaw(a,b,c,sa): persamaan 3 quads dan 1 spread pada segitiga
dengan panjang sisi a, b, c.


  triplespread(sa,sb,sc): persamaan 3 spread sa,sb,sc yang memebntuk
suatu segitiga


  doublespread(sa): Spread sudut rangkap Spread 2*phi, dengan
sa=sin(phi)^2 spread a.


## Luas, Lingkaran Luar, Lingkaran Dalam Segitiga

Untuk menggambar objek-objek geometri seperti titik, ruas garis,
garis, dan lainnya. Langkah pertama adalah menentukan rentang
sumbu-sumbu koordinat. Semua objek geometri akan digambar pada satu
bidang koordinat, sampai didefinisikan bidang koordinat yang baru.


## Mengatur luas bidang koordinat

\>setPlotRange(-1,2.5,-1,2.5): // mendefinisikan bidang koordinat baru 


![images/Afifah%20Setyaningsih_23030630009_Geometri-001.png](images/Afifah%20Setyaningsih_23030630009_Geometri-001.png)

Sekarang tetapkan tiga titik dan plot mereka.


Kita ambil 3 titik A, B, C, misalkan titik A pada koordinat (1,0)


## Menggambar Titik dan Ruas Garis

\>A=[1,0]; plotPoint(A,"A"): // definisi dan gambar tiga titik


![images/Afifah%20Setyaningsih_23030630009_Geometri-002.png](images/Afifah%20Setyaningsih_23030630009_Geometri-002.png)

Dalam plot tersebut dapat dilihat titik A. Selanjutnya kita ambil
titik B pada koordinat (0,1). 


\>B=[0,1]; plotPoint(B,"B"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-003.png](images/Afifah%20Setyaningsih_23030630009_Geometri-003.png)

Sekarang kita akan gambarkan titik C yang berada dalam kooordinat
(2,2).


\>C=[2,2]; plotPoint(C,"C"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-004.png](images/Afifah%20Setyaningsih_23030630009_Geometri-004.png)

Kemudian kita akan hubungkan titik A dan B menjadi sebuah garis yang
diberi nama "c".


\>plotSegment(A,B,"c"): // c=AB


![images/Afifah%20Setyaningsih_23030630009_Geometri-005.png](images/Afifah%20Setyaningsih_23030630009_Geometri-005.png)

\>plotSegment(B,C,"a"): // a=BC


![images/Afifah%20Setyaningsih_23030630009_Geometri-006.png](images/Afifah%20Setyaningsih_23030630009_Geometri-006.png)

\>plotSegment(A,C,"b"): // b=AC


![images/Afifah%20Setyaningsih_23030630009_Geometri-007.png](images/Afifah%20Setyaningsih_23030630009_Geometri-007.png)

Setelah kita menghubungkan setiap titiknya diperoleh suatu bidang
berupa segitiga "ABC" dengan ruas garis a, b, c.


Fungsi geometri meliputi fungsi untuk membuat garis dan lingkaran.
Format garis adalah [a,b,c], yang mewakili garis dengan persamaan
ax+by=c. Kita akan mencari persamaan garis yang melalui titik B dan C


## Menggambar Garis yang Melalui 2 Titik

\>lineThrough(B,C) // garis yang melalui B dan C


    [-1,  2,  2]

Setelah diperoleh garis melalui B dan C, kita cari garis tegak lurus
yang melalui A pada BC.


\>h=perpendicular(A,lineThrough(B,C)); // garis h tegak lurus BC melalui A


Dan persimpangannya dengan BC.


## Menggambar Titik Potong

\>D=lineIntersection(h,lineThrough(B,C)); // D adalah titik potong h dan BC


Setelah itu kita akan mencari koordinat titik D.


\>plotPoint(D, value=1) // koordinat D ditampilkan

\>aspect(1); plotSegment(A,D, "h"): // tampilkan semua gambar hasil plot...()


![images/Afifah%20Setyaningsih_23030630009_Geometri-008.png](images/Afifah%20Setyaningsih_23030630009_Geometri-008.png)

## Menghitung luas dari Segitiga ABC

$$L_{\triangle ABC}= \frac{1}{2}AD.BC.$$\>norm(A-D)\*norm(B-C)/2 // AD=norm(A-D), BC=norm(B-C)


    1.5

Atau kita bisa mencari luas segitiga tersebut dengan fungsi berikut.


\>distance(A,D)\*distance(B,C)/2 // hitung luas segitiga langusng dengan fungsi


    1.5

Cara lainnya lagi yaitu dengan menggunakan determinan dari 3 titik
yang sudah diketahui A(1,0), B(0,1), C(2,2), dengan rumus:


$$\frac{1}{2} {|x1(y2-y3)+x2(y3-y1)+x3(y1-y2)|}$$\>areaTriangle(A,B,C)


    1.5

## Menentukan Besar Sudut



Jika akan mecari sudut C dalam bentuk derajat


\>degprint(computeAngle(B,C,A))


    36°52'11.63''

## Menggambar Lingkaran Luar Segitiga

\>z=circleThrough(A,B,C); // lingkaran luar segitiga ABC

\>R=getCircleRadius(z); // jari2 lingkaran luar 

\>O=getCircleCenter(z); // titik pusat lingkaran z 

\>plotPoint(O,"O"); // gambar titik "O"

\>plotCircle(z,"Lingkaran luar segitiga ABC"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-011.png](images/Afifah%20Setyaningsih_23030630009_Geometri-011.png)

Dari gambar plot tersebut kita bisa menghitung koordinat titik pusat
dan jari-jari lingkaran luar dengan perintah berikut.


\>O, R


    [1.16667,  1.16667]
    1.17851130198

## Menggambar Lingkaran Dalam Segitiga

Sekarang kita akan menggambar lingkaran dalam segitiga ABC. Titik
pusat lingkaran dalam adalah titik potong garis-garis bagi sudut.


\>l=angleBisector(A,C,B); // garis bagi <ACB

\>g=angleBisector(C,A,B); // garis bagi <CAB

\>P=lineIntersection(l,g) // titik potong kedua garis bagi sudut


    [0.86038,  0.86038]

Setelah didapat titik koordinat P, tambahkan semuanya ke plot.


\>color(5); plotLine(l); plotLine(g); color(1); // gambar kedua garis bagi sudut

\>plotPoint(P,"P"); // gambar titik potongnya

\>r=norm(P-projectToLine(P,lineThrough(A,B))) // jari-jari lingkaran dalam


    0.509653732104

\>plotCircle(circleWithCenter(P,r),"Lingkaran dalam segitiga ABC"): // gambar lingkaran dalam


![images/Afifah%20Setyaningsih_23030630009_Geometri-012.png](images/Afifah%20Setyaningsih_23030630009_Geometri-012.png)

## Latihan

1. Tentukan ketiga titik singgung lingkaran dalam dengan sisi-sisi
segitiga ABC.


\>setPlotRange(-2.5,4.5,-2.5,4.5);

\>A=[-2,1]; plotPoint(A,"A");

\>B=[1,-2]; plotPoint(B,"B");

\>C=[4,4]; plotPoint(C,"C");


2. Gambar segitiga dengan titik-titik sudut ketiga titik singgung
tersebut.


\>plotSegment(A,B,"c")

\>plotSegment(B,C,"a")

\>plotSegment(A,C,"b")

\>aspect(1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-013.png](images/Afifah%20Setyaningsih_23030630009_Geometri-013.png)

3. Hitung luas segitiga tersebut.


\>areaTriangle(A,B,C)


    13.5

4. Tunjukkan bahwa garis bagi sudut yang ke tiga juga melalui titik
pusat lingkaran dalam.


\>l=angleBisector(A,C,B);

\>g=angleBisector(C,A,B);

\>P=lineIntersection(l,g)


    [0.581139,  0.581139]

\>color(5); plotLine(l); plotLine(g); color(1);

\>plotPoint(P,"P");

\>r=norm(P-projectToLine(P,lineThrough(A,B)))


    1.52896119631

\>plotCircle(circleWithCenter(P,r),"Lingkaran dalam segitiga ABC"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-014.png](images/Afifah%20Setyaningsih_23030630009_Geometri-014.png)

Jadi, terbukti bahwa garis bagi sudut yang ketiga juga melalui titik
pusat lingkaran dalam.


5. Gambar jari-jari lingkaran dalam.


\>r=norm(P-projectToLine(P,lineThrough(A,B)))


    1.52896119631

\>plotCircle(circleWithCenter(P,r),"Lingkaran dalam segitiga ABC"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-015.png](images/Afifah%20Setyaningsih_23030630009_Geometri-015.png)

# Persamaan Garis dan Koordinat Titik dg Geometri Simbolik

Kita dapat menghitung geometri eksak dan simbolik menggunakan Maxima.


Geometri simbolik adalah cabang geometri yang menggunakan
simbol-simbol matematis dan aljabar untuk merepresentasikan dan
memanipulasi objek-objek geometris, seperti titik, garis, bidang, dan
bangun tiga dimensi.


File geometri.e menyediakan fungsi yang sama (dan lebih banyak lagi)
di Maxima. Namun, kita dapat menggunakan perhitungan simbolis
sekarang.


## 1. Menentukan persamaan garis melalui 2 titik

\>A &= [1,0]; B &= [0,1]; C &= [2,2]; // menentukan tiga titik A, B, C

\>c &= lineThrough(B,C) // c=BC (persamaan garis yang melalui BC)


    
                                 [- 1, 2, 2]
    

## Mencari persamaan garis menggunakan metode simbolik.

\>$getLineEquation(c,x,y), $solve(%,y) | expand // persamaan garis a


$$2\,y-x=2$$$$\left[ y=\frac{x}{2}+1 \right] $$\>$getLineEquation(lineThrough(A,[x1,y1]),x,y) // persamaan garis melalui A dan (x1, y1)


$$\left({\it x_1}-1\right)\,y-x\,{\it y_1}=-{\it y_1}$$Selanjutnya, kita mencari garis yang tegak lurus dengan BC, dan
melalui titik A


\>h &= perpendicular(A,lineThrough(B,C)) // h melalui A tegak lurus BC


    
                                  [2, 1, 2]
    

Hasil [2, 1, 2] merepresentasikan garis dengan persamaan




Dimana persamaan tersebut tegak lurus dengan garis yang melewati titik
B dan C. serta  melalui titik A.


Mencari titik potong garis h dengan garis BC


## 2. Mencari titik potong garis h dengan BC

\>D &= lineIntersection(c,h) // D titik potong garis a=BC dan h


    
                                     2  6
                                    [-, -]
                                     5  5
    

Mencari proyeksi dari titik A ke titik D. Maksudnya, kita akan menarik
garis dari titik A menuju titik D. dan akan menghasilkan koordinat
yang sama 


\>$projectToLine(A,lineThrough(B,C)) // proyeksi A pada BC


$$\left[ \frac{2}{5} , \frac{6}{5} \right] $$## 3. Mencari panjang garis AD

\>$distance(A,D) // jarak AD


$$\frac{3}{\sqrt{5}}$$## 4. Menentukan titik pusat dan jari-jari

Menggunakan gambar lingkaran yang sudah tergambarkan pada materi
sebelumnya. Selanjutnya, kita bisa mencari titik pusat dan jari-jari
lingkaran dengan menggunakan fungsi geometri simbolik


\>cc &= circleThrough(A,B,C); $cc // (titik pusat dan jari-jari) lingkaran melalui A, B, C


$$\left[ \frac{7}{6} , \frac{7}{6} , \frac{5}{3\,\sqrt{2}} \right] $$* 
Menampilkan nilai jari-jari


\>r&=getCircleRadius(cc); $r , $float(r) // tampilkan nilai jari-jari dalam bentuk desimal


$$\frac{5}{3\,\sqrt{2}}$$$$1.178511301977579$$Mencari nilai sudut dari ACB


\>$computeAngle(A,C,B) // nilai <ACB


$$\arccos \left(\frac{4}{5}\right)$$## 6. Mencari persamaan garis bagi dan titik potong sudut ABC

\>$solve(getLineEquation(angleBisector(A,C,B),x,y),y)[1] // persamaan garis bagi <ACB


$$y=x$$Mencari titik potong 2 garis tersebut


\>P &= lineIntersection(angleBisector(A,C,B),angleBisector(C,B,A)); $P // titik potong 2 garis bagi sudut


$$\left[ \frac{\sqrt{2}\,\sqrt{5}+2}{6} , \frac{\sqrt{2}\,\sqrt{5}+2
 }{6} \right] $$\>P() // hasilnya sama dengan perhitungan sebelumnya


    [0.86038,  0.86038]

# Perpotongan garis dan lingkaran

Materi selanjutnya adalah memotong garis dengan lingkaran, dan
lingkaran dengan lingkaran.


\>A &:= [1,0]; c=circleWithCenter(A,4); //lingkaran dengan pusat A dan jari-jari 4

\>B &:= [1,2]; C &:= [2,1]; l=lineThrough(B,C); //garis yang melalui titik B dan C

\>setPlotRange(5); plotCircle(c); plotLine(l,"l"); plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-027.png](images/Afifah%20Setyaningsih_23030630009_Geometri-027.png)

Perpotongan garis dengan lingkaran menghasilkan dua titik dan jumlah
titik potong.


## Mencari titik koordinat P1 dan P2 dalam(x,y)

\>{P1,P2,f}=lineCircleIntersections(l,c); // titik potong garis l dan lingkaran c

\>P1, P2,


    [4.64575,  -1.64575]
    [-0.645751,  3.64575]

\>plotPoint(P1); plotPoint(P2):


![images/Afifah%20Setyaningsih_23030630009_Geometri-028.png](images/Afifah%20Setyaningsih_23030630009_Geometri-028.png)

Begitu pula di Maxima.


Menampilkan titik pusat dan jari-jari


\>c &= circleWithCenter(A,4) // lingkaran dengan pusat A(1,0) jari-jari 4


    
                                  [1, 0, 4]
    

Menampilkan persamaan garis l yang melalui garis BC


\>l &= lineThrough(B,C) // garis l melalui B dan C


    
                                  [1, 1, 3]
    

Hasil [1,1,3] merepresentasikan garis dengan persamaan


-Mencari titik potong antara sebuah garis l dan sebuah lingkaran c.


\>$lineCircleIntersections(l,c) | radcan, // titik potong lingkaran c dan garis m


$$\left[ \left[ \sqrt{7}+2 , 1-\sqrt{7} \right]  , \left[ 2-\sqrt{7}
  , \sqrt{7}+1 \right]  \right] $$Menyederhanakan hasil solusi menggunakan radcan, terutama jika hasil
melibatkan akar kuadrat.


## .



Akan ditunjukkan bahwa sudut-sudut yang menghadap busur yang sama
adalah sama besar.


\>C=A+normalize([-2,-3])\*4; plotPoint(C); plotSegment(P1,C); plotSegment(P2,C);

\>degprint(computeAngle(P1,C,P2))


    69°17'42.68''

\>C=A+normalize([-4,-3])\*4; plotPoint(C); plotSegment(P1,C); plotSegment(P2,C);

\>degprint(computeAngle(P1,C,P2))


    69°17'42.68''

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-030.png](images/Afifah%20Setyaningsih_23030630009_Geometri-030.png)

# Garis Sumbu

Berikut adalah langkah-langkah menggambar garis sumbu ruas garis AB:


1. Gambar lingkaran dengan pusat A melalui B.


2. Gambar lingkaran dengan pusat B melalui A.


3. Tarik garis melallui kedua titik potong kedua lingkaran tersebut.
Garis ini merupakan garis sumbu (melalui titik tengah dan tegak lurus)
AB.


* 
Mendefinisikan titik A dan titik B


\>A=[2,2]; B=[-1,-2];


* 
Membuat lingkaran C1 dan C2


\>c1=circleWithCenter(A,distance(A,B)); // titik pusat A

\>c2=circleWithCenter(B,distance(A,B)); // titik pusat B


## Mencari titik potong antara dua lingkaran

\>{P1,P2,f}=circleCircleIntersections(c1,c2);


-Membuat garis yang melalui P1 dan P2


\>l=lineThrough(P1,P2);


* 
Mengatur rentang, titik dan Memplot Lingkaran


\>setPlotRange(5); plotCircle(c1); plotCircle(c2);

\>plotPoint(A); plotPoint(B); plotSegment(A,B); plotLine(l,"l");

\>plotPoint(P1,"P1");

\>plotPoint(P2,"P2"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-031.png](images/Afifah%20Setyaningsih_23030630009_Geometri-031.png)

\>P1, P2,


    [3.9641,  -2.59808]
    [-2.9641,  2.59808]

Sehingga dapat disimpulkan garis yang melalui titik potong kedua
lingkaran tersebut adalah garis sumbu


## .

Selanjutnya, saya akan melakukan hal yang sama di Maxima dengan
koordinat secara umum.


* 
Membuat lingkaran dan mencari titik potong


\>A &= [a1,a2]; B &= [b1,b2];

\>c1 &= circleWithCenter(A,distance(A,B)); //lingkaran dengan titik pusat A

\>c2 &= circleWithCenter(B,distance(A,B)); //lingkaran dengan titik pusat B

\>P &= circleCircleIntersections(c1,c2); P1 &= P[1]; P2 &= P[2]; //titik potong kedua lingkaran


Persamaan bisa disederhanakan dengan memecahkan y.


Langkah pertama, menentukan persamaan garis yang melalui dua titik
potong P1 dan P2


\>g &= getLineEquation(lineThrough(P1,P2),x,y);

\>$solve(g,y)


$$\left[ y=\frac{-\left(2\,{\it b_1}-2\,{\it a_1}\right)\,x+{\it b_2}
 ^2+{\it b_1}^2-{\it a_2}^2-{\it a_1}^2}{2\,{\it b_2}-2\,{\it a_2}}
  \right] $$Persamaan ini biasanya berbentuk linear, y=mx+by  dengan m sebagai
gradien.


Selanjutnya adalah menghitung persamaan garis tegak lurus tengah dari
segmen yang menghubungkan A dan B. Garis tegak lurus tengah adalah
garis yang membagi segmen AB secara tegak lurus


\>$solve(getLineEquation(middlePerpendicular(A,B),x,y),y)


$$\left[ y=\frac{-\left(2\,{\it b_1}-2\,{\it a_1}\right)\,x+{\it b_2}
 ^2+{\it b_1}^2-{\it a_2}^2-{\it a_1}^2}{2\,{\it b_2}-2\,{\it a_2}}
  \right] $$Selanjutnya, kita juga menentukan persamaan garis yang melalui titik A
dan B:


\>h &=getLineEquation(lineThrough(A,B),x,y);

\>$solve(h,y)


$$\left[ y=\frac{\left({\it b_2}-{\it a_2}\right)\,x-{\it a_1}\,
 {\it b_2}+{\it a_2}\,{\it b_1}}{{\it b_1}-{\it a_1}} \right] $$Perhatikan hasil kali gradien garis g dan h adalah:


$$m1.m2= \frac{-(b_1-a_1)}{(b_2-a_2)}\times \frac{(b_2-a_2)}{(b_1-a_1)} = -1.$$Artinya kedua garis tegak lurus.


# Rumus Heron

Rumus Heron menyatakan bahwa luas segitiga dengan panjang sisi-sisi a,
b dan c adalah:


$$L = \sqrt{s(s-a)(s-b)(s-c)}\quad \text{ dengan } s=\frac{a+b+c}{2}.$$Untuk membuktikan rumus tersebut, kita misalkan C(0,0), B(a,0) dan
A(x,y), b=AC, c=AB. Berikut visualisasi bentuk dari bangun segitiga
tersebut.


\>setPlotRange(-1,10,-1,8); plotPoint([0,0], "C(0,0)"); plotPoint([5,0], "B(a,0)"); plotPoint([7,6], "A(x,y)");

\>plotSegment([0,0],[5,0], "a"); plotSegment([5,0],[7,6],"c"); plotSegment([0,0],[7,6],"b");

\>plotSegment([7,6],[7,0],"t=y"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-037.png](images/Afifah%20Setyaningsih_23030630009_Geometri-037.png)

Luas segitiga ABC adalah


$$L_{\triangle ABC}=\frac{1}{2}a\times y.$$Nilai y didapat dengan langkah-langkah berikut


$$AC = \sqrt{(x-0)^2+(y-0)^2}$$$$b = \sqrt{(x)^2+(y)^2}$$$$b^2 = x^2+y^2$$atau


$$AB = \sqrt{(x-a)^2+(y-0)^2}$$$$c = \sqrt{(x-a)^2+(y)^2}$$$$c^2 = (x-a)^2+y^2$$kita akan peroleh persamaan :


$$x^2+y^2=b^2$$

persamaan tersebut menyatakan bahwa titik (x,y) berjarak dari titik
C(0,0)


$$\quad (x-a)^2+y^2=c^2.$$

persamaan tersebut menyatakan bahwa titik A(x,y) berjarak c dari titik
B(a,0)


\>sol &= solve([x^2+y^2=b^2,(x-a)^2+y^2=c^2],[x,y])


    
                    2    2    2
                 - c  + b  + a
           [[x = --------------, y = 
                      2 a
              4      2  2      2  2    4      2  2    4
      sqrt(- c  + 2 b  c  + 2 a  c  - b  + 2 a  b  - a )
    - --------------------------------------------------], 
                             2 a
            2    2    2
         - c  + b  + a
    [x = --------------, y = 
              2 a
            4      2  2      2  2    4      2  2    4
    sqrt(- c  + 2 b  c  + 2 a  c  - b  + 2 a  b  - a )
    --------------------------------------------------]]
                           2 a
    

Setelah mendapat solusi, ekstrak solusi y.


\>ysol &= y with sol[2][2]; $ysol


$$\frac{\sqrt{-c^4+2\,b^2\,c^2+2\,a^2\,c^2-b^4+2\,a^2\,b^2-a^4}}{2\,a
 }$$Kita telah mendapatkan nilai y, selanjutnya kita akan memasukkan nilai
y ke dalam rumus luas segitiga.


\>function H(a,b,c) &= sqrt(factor((ysol\*a/2)^2)); $'H(a,b,c)=H(a,b,c)


$$H\left(a , b , c\right)=\frac{\sqrt{\left(-c+b+a\right)\,\left(c-b+
 a\right)\,\left(c+b-a\right)\,\left(c+b+a\right)}}{4}$$Terbukti bahwa rumus heron merupakan rumus luas segituga jika
diketahui ketiga sisinya.


\>H(3,4,5) //luas segitiga siku-siku dengan panjang sisi 3, 4, 5


    6

Dan jelas, bahwa 6 adalah segitiga dengan luas maksimal dan dua sisi 3
dan 4.


\>aspect (1.5); plot2d(&H(3,4,x),1,7): // Kurva luas segitiga sengan panjang sisi 3, 4, x (1<= x <=7)


![images/Afifah%20Setyaningsih_23030630009_Geometri-049.png](images/Afifah%20Setyaningsih_23030630009_Geometri-049.png)

Gambar kurva luas segitiga dengan panjang sisi 3,4,x


## Menggambar elips dengan substitusi

Selanjutnya kita cari himpunan semua titik di mana b+c=d untuk
beberapa konstanta d.


\>$solve(diff(H(a,b,c)^2,c)=0,c)


$$\left[ c=-\sqrt{b^2+a^2} , c=\sqrt{b^2+a^2} , c=0 \right] $$Diketahui bahwa ini adalah elips.


Substitusi b = d-c ke dalam solusi x dan y


\>s1 &= subst(d-c,b,sol[2]); $s1


$$\left[ x=\frac{\left(d-c\right)^2-c^2+a^2}{2\,a} , y=\frac{\sqrt{-
 \left(d-c\right)^4+2\,c^2\,\left(d-c\right)^2+2\,a^2\,\left(d-c
 \right)^2-c^4+2\,a^2\,c^2-a^4}}{2\,a} \right] $$Buat suatu fungsi dari hasil substitusi tersebut.


\>function fx(a,c,d) &= rhs(s1[1]); $fx(a,c,d), function fy(a,c,d) &= rhs(s1[2]); $fy(a,c,d)


$$\frac{\left(d-c\right)^2-c^2+a^2}{2\,a}$$$$\frac{\sqrt{-\left(d-c\right)^4+2\,c^2\,\left(d-c\right)^2+2\,a^2\,
 \left(d-c\right)^2-c^4+2\,a^2\,c^2-a^4}}{2\,a}$$Sekarang kita bisa menggambar plotnya. Ambil sisi b dengan rentang
dari 1 hingga 4. Diketahui bahwa kita mendapatkan elips.


\>aspect(1); plot2d(&fx(3,x,5),&fy(3,x,5),xmin=1,xmax=4,square=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-054.png](images/Afifah%20Setyaningsih_23030630009_Geometri-054.png)

Kita dapat memeriksa persamaan umum untuk elips ini, yaitu.


$$\frac{(x-x_m)^2}{u^2}+\frac{(y-y_m)^2}{v^2}=1,$$di mana (xm,ym) adalah pusat, sedangkan u dan v adalah setengah sumbu.


\>$ratsimp((fx(a,c,d)-a/2)^2/u^2+fy(a,c,d)^2/v^2 with [u=d/2,v=sqrt(d^2-a^2)/2])


$$1$$Dari hasil tersebut terbukti bahwa persamaan umum elips tersebut
menghasilkan 1


## .

Luas segitiga akan mencapai nilai maksimum ketika segitiga tersebut
berbentuk segitiga sama sisi. Hal ini karena jumlah panjang ketiga
sisi segitiga (a + b + c = d) adalah konstan. Dari sini kita bisa
menunjukkan secara analitis bahwa segitiga dengan luas terbesar akan
menjadi segitiga sama sisi.


\>eqns &= [diff(H(a,b,d-(a+b))^2,a)=0,diff(H(a,b,d-(a+b))^2,b)=0]; $eqns


$$\left[ \frac{d\,\left(d-2\,a\right)\,\left(d-2\,b\right)}{8}-\frac{
 \left(-d+2\,b+2\,a\right)\,d\,\left(d-2\,b\right)}{8}=0 , \frac{d\,
 \left(d-2\,a\right)\,\left(d-2\,b\right)}{8}-\frac{\left(-d+2\,b+2\,
 a\right)\,d\,\left(d-2\,a\right)}{8}=0 \right] $$Dari hasil tersebut diperoleh persamaan untuk mencari nilai a dan b
yang meminimalkan fungsi dan solusinya a=b=c=d/3. Selanjutnya
menyelesaikan sistem persamaan dengan variabel a dan b.


\>$solve(eqns,[a,b])


$$\left[ \left[ a=\frac{d}{3} , b=\frac{d}{3} \right]  , \left[ a=0
  , b=\frac{d}{2} \right]  , \left[ a=\frac{d}{2} , b=0 \right]  , 
 \left[ a=\frac{d}{2} , b=\frac{d}{2} \right]  \right] $$Selain itu, bisa juga menggunakan metode Lagrange, memaksimalkan
H(a,b,c)^2 terhadap a+b+c=d.


\>&solve([diff(H(a,b,c)^2,a)=la,diff(H(a,b,c)^2,b)=la, ...  
\>      diff(H(a,b,c)^2,c)=la,a+b+c=d],[a,b,c,la])


    
                         d      d
            [[a = 0, b = -, c = -, la = 0], 
                         2      2
         d             d                d      d
    [a = -, b = 0, c = -, la = 0], [a = -, b = -, c = 0, la = 0], 
         2             2                2      2
                                3
         d      d      d       d
    [a = -, b = -, c = -, la = ---]]
         3      3      3       108
    

Membuat plot situasi. Pertama-tama atur titik koordinat di Maxima.


\>A &= at([x,y],sol[2]); $A


$$\left[ \frac{-c^2+b^2+a^2}{2\,a} , \frac{\sqrt{-c^4+2\,b^2\,c^2+2\,
 a^2\,c^2-b^4+2\,a^2\,b^2-a^4}}{2\,a} \right] $$\>B &= [0,0]; $B, C &= [a,0]; $C


$$\left[ 0 , 0 \right] $$$$\left[ a , 0 \right] $$Kemudian atur rentang plot, dan plot titik-titiknya.


\>setPlotRange(0,10,-2,10); ...  
\>   a=5; b=5; c=5; ...  
\>   plotPoint(mxmeval("B"),"B"); plotPoint(mxmeval("C"),"C"); ...  
\>   plotPoint(mxmeval("A"),"A"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-062.png](images/Afifah%20Setyaningsih_23030630009_Geometri-062.png)

Menggambar garis dengan plotSegment


\>plotSegment(mxmeval("A"),mxmeval("C")); ...  
\>   plotSegment(mxmeval("B"),mxmeval("C")); ...  
\>   plotSegment(mxmeval("B"),mxmeval("A")):


![images/Afifah%20Setyaningsih_23030630009_Geometri-063.png](images/Afifah%20Setyaningsih_23030630009_Geometri-063.png)

Menghitung garis sumbu tengah tegak lurus (perpendicular bisectors)
menggunakan maxima.


\>h &= middlePerpendicular(A,B); g &= middlePerpendicular(B,C);


Dan mencari bagian tengah lingkar.


\>p &= lineIntersection(h,g);


Selanjutnya, kita bisa mencari jari-jari lingkaran dengan perintah
berikut.


\>&assume(a\>0,b\>0,c\>0); $distance(p,B) | radcan


$$\frac{i\,a\,b\,c}{\sqrt{c-b-a}\,\sqrt{c-b+a}\,\sqrt{c+b-a}\,\sqrt{c
 +b+a}}$$Setelah mendapatkannya, kita tambahkan semua ke dalam plot.


\>plotPoint(p()); 

\>plotCircle(circleWithCenter(mxmeval("p"),mxmeval("distance(p,C)"))):


![images/Afifah%20Setyaningsih_23030630009_Geometri-065.png](images/Afifah%20Setyaningsih_23030630009_Geometri-065.png)

Menggunakan geometri, kami memperoleh rumus sederhana


$$\frac{a}{\sin(\alpha)}=2r$$untuk radiusnya. Kami dapat memeriksa, apakah ini benar dengan Maxima.
Maxima akan memfaktorkan ini hanya jika kita kuadratkan.


\>$c^2/sin(computeAngle(A,B,C))^2  | factor


$$-\frac{4\,a^2\,b^2\,c^2}{\left(c-b-a\right)\,\left(c-b+a\right)\,
 \left(c+b-a\right)\,\left(c+b+a\right)}$$# Garis Euler

Garis Euler adalah garis yang ditentukan dari sembarang segitiga yang
tidak sama sisi. Ini adalah garis tengah segitiga, dan melewati
beberapa titik penting yang ditentukan dari segitiga, termasuk
orthocenter, circumcenter, centroid, titik Exeter dan pusat lingkaran
sembilan titik segitiga.


Orthocenter: Titik perpotongan garis tinggi.


Circumcenter: Titik pusat lingkaran luar segitiga.


Centroid: Titik berat atau pusat massa segitiga.


Titik Exeter: Titik istimewa yang terletak pada sumbu Euler.


Pusat lingkaran sembilan titik: Titik pusat lingkaran sembilan titik
yang melalui beberapa titik penting pada segitiga.


Pertama, mendefinisikan sudut sudut segitiga yang akan digunakan dalam
menghitung garis euler. Sudut-sudut ini akan diekspresikan dalam
bentuk simbolik atau aljabar, sehingga mempermudah perhitungan lebih
lanjut yang berkaitan dengan segitiga tersebut.


Untuk memplot objek geometris, harus menyiapkan area plot dan
menambahkan titik titik ke area tersebut. Semua plot objek geometris
kita tambahkan ke plot saat ini.


Ambil 3 titik, titik A di koordinat (-1,-1), titik B di koordinat
(2,0), titik C di koordinat (1,2). Atur rentang plot pada sumbu x dan
y sehingga tampilan grafik mencakup rentang dari -4 hingga 4.


\>A::=[-1,-1]; B::=[2,0]; C::=[1,2];

\>setPlotRange(4); plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-068.png](images/Afifah%20Setyaningsih_23030630009_Geometri-068.png)

Setelah memplot titik A,B, dan C, selanjutnya memplot tiga segmen
garis yang menghubungkan titik A ke B, B ke C, dan C kembali ke A,
sehingga membentuk segitiga. Untuk garis dari titik A ke B dinamakan
c, B ke C dinamakan b, dan C ke A dinamakan a. 


\>plotSegment(A,B,"c"); plotSegment(B,C,"b"); plotSegment(C,A,"a"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-069.png](images/Afifah%20Setyaningsih_23030630009_Geometri-069.png)

Mencari luas segitiga menggunakan rumus determinan.


$$Det = \left[\begin{matrix}x_1 & y_1 & 1 \\x_2 & y_2 & 1\\x_3 & y_3 & 1\end{matrix}\right]$$$$Luas = \frac{1}{2}\vert{Det}\vert$$$$Luas = \frac{1}{2}\vert{x_1(y_2-y_3)+ x_2(y_3-y_1)+ x_3(y_1-y_2)}\vert$$\>$areaTriangle(A,B,C)


$$-\frac{7}{2}$$Ambil nilai absolutnya


$$\frac{7}{2}$$Selanjutnya, menghitung koefisien sisi c. Sisi c ini berguna untuk
menentukan lingkaran luar segitiga.


\>c &= lineThrough(A,B)


    
                                [- 1, 3, - 2]
    

Yang merepresentasikan persamaan garis dalam bentuk


\>$getLineEquation(c,x,y)


$$3\,y-x=-2$$Bentuk umum dari rumus ini adalah


$$Ax+By+C=0.$$Untuk bentuk Hesse, perlu menentukan sebuah titik, sehingga titik
tersebut berada di sisi positif dari bentuk Hesse. Memasukkan titik
menghasilkan jarak positif ke garis. Keuntungan dari bentuk Hesse
adalah memungkinkan perhitungan jarak dari suatu titik ke garis secara
langsung, karena persamaan ini mengubah koefisien A dan B menjadi
bentuk yang dinormalisasi (memiliki panjang 1).


Bentuk Hesse dsri persamaan garis :


$$\frac{Ax+By+C}{\sqrt{A^2+B^2}} = 0$$\>$getHesseForm(c,x,y,C), $at(%,[x=C[1],y=C[2]])


$$\frac{3\,y-x+2}{\sqrt{10}}$$$$\frac{7}{\sqrt{10}}$$# Lingkaran Luar dan Lingkaran Dalam

\>LL &= circleThrough(A,B,C); $getCircleEquation(LL,x,y)


$$\left(y-\frac{5}{14}\right)^2+\left(x-\frac{3}{14}\right)^2=\frac{
 325}{98}$$\>O &= getCircleCenter(LL); $O


$$\left[ \frac{3}{14} , \frac{5}{14} \right] $$\>plotCircle(LL()); plotPoint(O(),"O"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-082.png](images/Afifah%20Setyaningsih_23030630009_Geometri-082.png)

Menentukan perpotongan ketinggian di ABC (orthocenter) secara numerik
dengan perintah berikut.


H adalah titik orthocenter yang merupakan titik perpotongan dari tiga
garis tinggi segitiga. 


\>H &= lineIntersection(perpendicular(A,lineThrough(C,B)),...  
\>     perpendicular(B,lineThrough(A,C))); $H


$$\left[ \frac{11}{7} , \frac{2}{7} \right] $$Sekarang kita dapat menghitung garis Euler dari segitiga.


\>el &= lineThrough(H,O); $getLineEquation(el,x,y)


$$-\frac{19\,y}{14}-\frac{x}{14}=-\frac{1}{2}$$Tambahkan ke plot di bawah 


\>plotPoint(H(),"H"); plotLine(el(),"Garis Euler"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-085.png](images/Afifah%20Setyaningsih_23030630009_Geometri-085.png)

Pusat gravitasi harus berada di garis ini.


\>M &= (A+B+C)/3; $getLineEquation(el,x,y) with [x=M[1],y=M[2]]


$$-\frac{1}{2}=-\frac{1}{2}$$\>plotPoint(M(),"M"): // titik berat


![images/Afifah%20Setyaningsih_23030630009_Geometri-087.png](images/Afifah%20Setyaningsih_23030630009_Geometri-087.png)

Diketahui


Sederhanakan dengan radcan untuk mencapai ini.


\>$distance(M,H)/distance(M,O)|radcan


$$2$$Fungsi termasuk fungsi untuk sudut juga. Sudut antara titik-titik
sudut segitiga A, B, dan C dihitung menggunakan perintah berikut :


\>$computeAngle(A,C,B), degprint(%())


$$\arccos \left(\frac{4}{\sqrt{5}\,\sqrt{13}}\right)$$    60°15'18.43''

Persamaan untuk pusat incircle tidak terlalu bagus.


\>Q &= lineIntersection(angleBisector(A,C,B),angleBisector(C,B,A))|radcan; $Q


$$\left[ \frac{\left(2^{\frac{3}{2}}+1\right)\,\sqrt{5}\,\sqrt{13}-15
 \,\sqrt{2}+3}{14} , \frac{\left(\sqrt{2}-3\right)\,\sqrt{5}\,\sqrt{
 13}+5\,2^{\frac{3}{2}}+5}{14} \right] $$Pusat lingkaran dalam didapatkan melalui persilangan bisektor dari dua
sudut. Garis bisektor dibentuk dari pasangan sudut ACB dan CBA. 


Jari-jari Lingkaran Dalam


\>r &= distance(Q,projectToLine(Q,lineThrough(A,B)))|ratsimp; $r


$$\frac{\sqrt{\left(-41\,\sqrt{2}-31\right)\,\sqrt{5}\,\sqrt{13}+115
 \,\sqrt{2}+614}}{7\,\sqrt{2}}$$\>LD &=  circleWithCenter(Q,r); // Lingkaran dalam

\>color(5); plotCircle(LD()):


![images/Afifah%20Setyaningsih_23030630009_Geometri-092.png](images/Afifah%20Setyaningsih_23030630009_Geometri-092.png)

## Parabola

Selanjutnya akan dicari persamaan tempat kedudukan titik-titik yang berjarak sama ke titik C
dan ke garis AB.


\>p &= getHesseForm(lineThrough(A,B),x,y,C)-distance([x,y],C); $p='0


$$\frac{3\,y-x+2}{\sqrt{10}}-\sqrt{\left(2-y\right)^2+\left(1-x
 \right)^2}=0$$Persamaan tersebut dapat digambar menjadi satu dengan gambar sebelumnya.


\>plot2d(p,level=0,add=1,contourcolor=6):


![images/Afifah%20Setyaningsih_23030630009_Geometri-094.png](images/Afifah%20Setyaningsih_23030630009_Geometri-094.png)

Ini seharusnya menjadi beberapa fungsi, tetapi pemecah default Maxima
hanya dapat menemukan solusinya, jika kita kuadratkan persamaannya.
sehingga mendapatkan solusi palsu.


\>akar &= solve(getHesseForm(lineThrough(A,B),x,y,C)^2-distance([x,y],C)^2,y)


    
            [y = - 3 x - sqrt(70) sqrt(9 - 2 x) + 26, 
                                  y = - 3 x + sqrt(70) sqrt(9 - 2 x) + 26]
    

Solusi pertama adalah


$$y=-3\,x-\sqrt{70}\,\sqrt{9-2\,x}+26$$Menambahkan solusi pertama ke plot menunjukkan bahwa itu merupakan
yang dicari. Teorinya memberi tahu bahwa itu adalah parabola yang
diputar.


\>plot2d(&rhs(akar[1]),add=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-096.png](images/Afifah%20Setyaningsih_23030630009_Geometri-096.png)

\>function g(x) &= rhs(akar[1]); $'g(x)= g(x)// fungsi yang mendefinisikan kurva di atas


$$g\left(x\right)=-3\,x-\sqrt{70}\,\sqrt{9-2\,x}+26$$\>T &=[-1, g(-1)]; // ambil sebarang titik pada kurva tersebut

\>dTC &= distance(T,C); $fullratsimp(dTC), $float(%) // jarak T ke C


$$\sqrt{1503-54\,\sqrt{11}\,\sqrt{70}}$$$$2.135605779339061$$\>U &= projectToLine(T,lineThrough(A,B)); $U // proyeksi T pada garis AB 


$$\left[ \frac{80-3\,\sqrt{11}\,\sqrt{70}}{10} , \frac{20-\sqrt{11}\,
 \sqrt{70}}{10} \right] $$\>dU2AB &= distance(T,U); $fullratsimp(dU2AB), $float(%) // jatak T ke AB


$$\sqrt{1503-54\,\sqrt{11}\,\sqrt{70}}$$$$2.135605779339061$$Kesimpulan : jarak titik T ke titik C sama dengan jarak titik T ke
garis AB. Perhitungan ini menunjukkan bahwa proyeksi titik T pada
garis AB menghasilkan jarak yang sama dengan jarak langsung antara T
dan C, sehingga memperlihatkan bahwa titik C terletak pada garis AB.


## Latihan

1. Gambarkan segitiga dengan titik A(0,0), B(4,1), dan C(1,4). Lalu
tentukan :


a. luas mengunakan determinan dari 3 titik


b. Hitung masing-masing sudut yang terbentuk


\>setPlotRange(-5,5,-5,5);

\>A=[0,0]; plotPoint(A,"A"); B=[4,1]; plotPoint(B,"B"); C=[1,4]; plotPoint(C,"C");

\>plotSegment(A,B,"c"); plotSegment(B,C,"a"); plotSegment(A,C,"b"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-103.png](images/Afifah%20Setyaningsih_23030630009_Geometri-103.png)

a. luas mengunakan determinan dari 3 titik


\>areaTriangle(A,B,C)


    7.5

b. masing-masing sudut yang terbentuk


\>degprint(computeAngle(B,A,C))


    61°55'39.05''

\>degprint(computeAngle(A,B,C))


    59°2'10.48''

\>degprint(computeAngle(A,C,B))


    59°2'10.48''

2.  Diketahui sisi segita sembarang yaitu sisi p = 6, sisi q = 12, dan
sisi r = 15.


a. Hitunglah luas segitiga tersebut menggunakan rumus heron!


b. Gambarkan kurva luas segitiga tersebut!


Penyelesaian :


a. Luas segitiga menggunakan rumus heron


\>sol &= solve([x^2+y^2=q^2,(x-p)^2+y^2=r^2],[x,y])


    
                     2    2    2
                  - r  + q  + p
            [[x = --------------, y = 
                       2 p
              4      2  2      2  2    4      2  2    4
      sqrt(- r  + 2 q  r  + 2 p  r  - q  + 2 p  q  - p )
    - --------------------------------------------------], 
                             2 p
            2    2    2
         - r  + q  + p
    [x = --------------, y = 
              2 p
            4      2  2      2  2    4      2  2    4
    sqrt(- r  + 2 q  r  + 2 p  r  - q  + 2 p  q  - p )
    --------------------------------------------------]]
                           2 p
    

\>ysol &= y with sol[2][2]; $ysol


$$\left[ \frac{\sqrt{-b^4+2\,a^2\,b^2+2\,b^2-a^4+2\,a^2-1}}{2\,a} , 
 \frac{\sqrt{-b^4+2\,a^2\,b^2+18\,b^2-a^4+18\,a^2-81}}{2\,a} , \frac{
 \sqrt{-b^4+2\,a^2\,b^2+8\,b^2-a^4+8\,a^2-16}}{2\,a} \right] $$\>function H(p,q,r) &= sqrt(factor((ysol\*p/2)^2)); $'H(p,q,r)=H(p,q,r)


$$H\left(\frac{3\,y-x+2}{\sqrt{10}}-\sqrt{\left(2-y\right)^2+\left(1-
 x\right)^2} , q , \frac{\sqrt{\left(-41\,\sqrt{2}-31\right)\,\sqrt{5
 }\,\sqrt{13}+115\,\sqrt{2}+614}}{7\,\sqrt{2}}\right)=\left[ \frac{
 \sqrt{\left(-b+a-1\right)\,\left(b-a-1\right)}\,\sqrt{b+a-1}\,\sqrt{
 b+a+1}\,\left| \sqrt{10}\,\sqrt{y^2-4\,y+x^2-2\,x+5}-3\,y+x-2
 \right| }{4\,\sqrt{10}\,a} , \frac{\sqrt{\left(-b+a+3\right)\,\left(
 b-a+3\right)\,\left(b+a-3\right)}\,\sqrt{b+a+3}\,\left| \sqrt{10}\,
 \sqrt{y^2-4\,y+x^2-2\,x+5}-3\,y+x-2\right| }{4\,\sqrt{10}\,a} , 
 \frac{\sqrt{\left(-b+a-2\right)\,\left(b-a-2\right)}\,\sqrt{b+a-2}\,
 \sqrt{b+a+2}\,\left| \sqrt{10}\,\sqrt{y^2-4\,y+x^2-2\,x+5}-3\,y+x-2
 \right| }{4\,\sqrt{10}\,a} \right] $$\>H(6,12,15)


    Wrong argument!
    
    Cannot combine a symbolic expression here.
    Did you want to create a symbolic expression?
    Then start with &amp;.
    
    Try "trace errors" to inspect local variables after errors.
    H:
        useglobal; return sqrt(-(c-b-a)*(c-b+a)*(c+b-a))*sqrt(c+b+a)* ...
    Error in:
    H(6,12,15) ...
              ^

b. Kurva luas segitiga tersebut


\>aspect (1.5); plot2d(&H(6,12,x),1,16):


    Variable y not found!
    Use global variables or parameters for string evaluation.
    Error in ^
    Error in expression: [sqrt((-b+a-1)*(b-a-1))*sqrt(b+a-1)*sqrt(b+a+1)*abs(sqrt(10)*sqrt(y^2-4*y+x^2-2*x+5)-3*y+x-2)/(4*sqrt(10)*a),sqrt((-b+a+3)*(b-a+3)*(b+a-3))*sqrt(b+a+3)*abs(sqrt(10)*sqrt(y^2-4*y+x^2-2*x+5)-3*y+x-2)/(4*sqrt(10)*a),sqrt((-b+a-2)*(b-a-2))*sqrt(b+a-2)*sqrt(b+a+2)*abs(sqrt(10)*sqrt(y^2-4*y+x^2-2*x+5)-3*y+x-2)/(4*sqrt(10)*a)]
    %ploteval:
        y0=f$(x[1],args());
    adaptiveevalone:
        s=%ploteval(g$,t;args());
    Try "trace errors" to inspect local variables after errors.
    plot2d:
        dw/n,dw/n^2,dw/n,auto;args());

# Trigonometri Rasional

Ini terinspirasi dari ceramah N.J.Wildberger. Dalam bukunya "Divine
Proportions", Wildberger mengusulkan untuk mengganti pengertian klasik
tentang jarak dan sudut dengan kuadrat dan penyebaran. Dengan
menggunakan ini, memang mungkin untuk menghindari fungsi trigonometri
dalam banyak contoh, dan tetap "rasional".


Intinya adalah bahwa perhitungan rasional simbolis sering kali
menghasilkan hasil yang sederhana. Sebaliknya, trigonometri klasik
menghasilkan hasil trigonometri yang rumit, yang hanya mengevaluasi
perkiraan numerik.


\>load geometry;


Untuk pengenalan pertama,menggunakan segitiga persegi panjang dengan
proporsi Mesir terkenal 3, 4 dan 5. Perintah berikut adalah perintah
Euler untuk merencanakan geometri bidang yang terdapat dalam file
Euler "geometry.e".


\>C&:=[0,0]; A&:=[4,0]; B&:=[0,3]; ...  
\>   setPlotRange(-1,5,-1,5); ...  
\>   plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"); ...  
\>   plotSegment(B,A,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"); ...  
\>   insimg(30);


![images/Afifah%20Setyaningsih_23030630009_Geometri-106.png](images/Afifah%20Setyaningsih_23030630009_Geometri-106.png)

menghitung sudut


$$\sin(w_a)=\frac{a}{c},$$di mana wa adalah sudut di A. Cara yang biasa untuk menghitung sudut
ini, adalah dengan mengambil invers dari fungsi sinus. Hasilnya adalah
sudut yang hanya dapat dicetak kira-kira.


menghitung sudut


wa dengan menggunakan fungsi


rcsin dari


$$\frac{3}{5}$$

. Hasilnya akan memberikan nilai sudut dalam radian, dan kemudian akan
dicetak dalam derajat menggunakan degprint.


1. menghitung wa


$$w_a=arcsin\frac{3}{5}=0.6435$$

2. konversi ke derajat:


$$derajat=radian*\frac{180}{\pi} = 36.87$$

3. Pisahkan bagian derajat:


$$Bagian bulat adalah 36^{\circ}.$$

4. Ambil bagian desimal:


Ambil 0.87 dari 36.87 dan kalikan dengan 60 untuk mendapatkan menit:


$$0.87 * 60 = 52.2 menit$$

Bagian bulat adalah 52'


5. Ambil bagian desimal menit:


Ambil 0.2 dan kalikan dengan 60 untuk mendapatkan detik:


$$0.2 * 60 = 12 detik$$

6.Tentukan detik dengan lebih presisi:


$$0.2 * 60 = 12 + 0.2 * 60 = 11.63 detik$$Hasil Akhir


Gabungkan hasilnya :


$$36^{\circ}52'11.63''$$\>wa := arcsin(3/5); degprint(wa)


    36°52'11.63''

Trigonometri rasional mencoba menghindari hal ini.


Gagasan pertama trigonometri rasional adalah kuadran, yang
menggantikan jarak. Sebenarnya, itu hanya jarak kuadrat. Berikut ini,
a, b, dan c menunjukkan kuadrat dari sisi-sisinya.


Teorema Pythogoras menjadi a+b=c.


$$a + b = c$$$$(3^2)+(4^2)=5^2$$$$9+16=25$$$$25=25$$\>a &= 3^2; b &= 4^2; c &= 5^2; &a+b=c


    
                                   25 = 25
    

Pengertian kedua dari trigonometri rasional adalah penyebaran. Spread
mengukur pembukaan antar baris. Ini adalah 0, jika garis-garisnya
sejajar, dan 1, jika garis-garisnya persegi panjang. Ini adalah
kuadrat sinus sudut antara dua garis.


Penyebaran garis AB dan AC pada gambar di atas didefinisikan sebagai:


$$s_a = \sin(\alpha)^2 = \frac{a}{c},$$di mana a dan c adalah kuadrat dari sembarang segitiga siku-siku
dengan salah satu sudut di A.


$$s_a = \sin(\alpha)^2 = \frac{a}{c} => s_a = \frac{3^2}{5^2} = \frac{9}{25}$$\>sa &= a/c; $sa


$$\frac{9}{25}$$kita dapat mengonversi nilai perkiraan untuk sudut wa menjadi sprad,
dan mencetaknya sebagai pecahan.


$$\sin(w_a)=\frac{a}{c}$$$$\sin(w_a)=\frac{3}{5}$$$$\sin(w_a)^2=(\frac{3}{5})^2$$$$\sin(w_a)^2=\frac{9}{25}$$\>fracprint(sin(wa)^2)


    9/25

Hukum kosinus trgonometri klasik diterjemahkan menjadi "hukum silang"
berikut.


$$(c+b-a)^2 = 4 b c \, (1-s_a)$$Di sini a, b, dan c adalah kuadrat dari sisi-sisi segitiga, dan sa
adalah penyebaran sudut A. Sisi a, seperti biasa, berhadapan dengan
sudut A.


\>$crosslaw(aa,bb,cc,saa)


$$\left[ \left({\it bb}-{\it aa}+\frac{7}{6}\right)^2 , \left(
 {\it bb}-{\it aa}+\frac{7}{6}\right)^2 , \left({\it bb}-{\it aa}+
 \frac{5}{3\,\sqrt{2}}\right)^2 \right] =\left[ \frac{14\,{\it bb}\,
 \left(1-{\it saa}\right)}{3} , \frac{14\,{\it bb}\,\left(1-{\it saa}
 \right)}{3} , \frac{5\,2^{\frac{3}{2}}\,{\it bb}\,\left(1-{\it saa}
 \right)}{3} \right] $$Dalam kasus kami, kami mendapatkan


$$(c+b-a)^2 = 4 b c \, (1-s_a)$$$$(25+16-9)^2 = 4*16*25 \, (1-\frac{9}{25})$$$$(32)^2 = 1600 \, (\frac{16}{25})$$$$(32)^2 = 64 \, (16)$$$$1024=1024$$\>$crosslaw(a,b,c,sa)


$$1024=1024$$Mari kita gunakan crosslaw ini untuk mencari spread di A. Untuk
melakukan ini, kita buat crosslaw untuk kuadran a, b, dan c, dan
selesaikan untuk spread yang tidak diketahui sa.


$$(c+b-a)^2 = 4 b c \, (1-x)$$$$(25+16-9)^2 = 4*16*25 \, (1-x)$$$$1024=1600 (1 - x)$$$$x = \frac{9}{25}$$\>$crosslaw(a,b,c,x), $solve(%,x)


$$1024=1600\,\left(1-x\right)$$$$\left[ x=\frac{9}{25} \right] $$Kita sudah tahu ini. Definisi spread adalah kasus khusus dari
crosslaw.


Kita juga dapat menyelesaikan ini untuk umum a,b,c. Hasilnya adalah
rumus yang menghitung penyebaran sudut segitiga yang diberikan kuadrat
dari ketiga sisinya.


\>$solve(crosslaw(aa,bb,cc,x),x)


$$\left[ \left[ \frac{168\,{\it bb}\,x+36\,{\it bb}^2+\left(-72\,
 {\it aa}-84\right)\,{\it bb}+36\,{\it aa}^2-84\,{\it aa}+49}{36} , 
 \frac{168\,{\it bb}\,x+36\,{\it bb}^2+\left(-72\,{\it aa}-84\right)
 \,{\it bb}+36\,{\it aa}^2-84\,{\it aa}+49}{36} , \frac{15\,2^{\frac{
 5}{2}}\,{\it bb}\,x+18\,{\it bb}^2+\left(-36\,{\it aa}-15\,2^{\frac{
 3}{2}}\right)\,{\it bb}+18\,{\it aa}^2-15\,2^{\frac{3}{2}}\,{\it aa}
 +25}{18} \right] =0 \right] $$Kita bisa membuat fungsi dari hasilnya.


$$a = 3^2; b = 4^2; c = 5^2$$$$x = [\frac{-c^2-(-2*b-2*a)c-b^2+2*a*b-a^2}{4*b*c}]$$$$x = [\frac{-25^2-(-2*16-2*9)25-16^2+2*9*16-9^2}{4*16*25}]$$$$x = [\frac{-625-(-32-18)25-256+288-81}{1600}]$$$$x = [\frac{576}{1600}]$$$$x = \frac{9}{25}$$\>$spread(a,b,c)


$$\frac{9}{25}$$Sebagai contoh, kita dapat menggunakannya untuk menghitung sudut
segitiga dengan sisi


$$a, \quad a, \quad \frac{4a}{7}$$Hasilnya rasional, yang tidak begitu mudah didapat jika kita
menggunakan trigonometri klasik.


$$x = [\frac{-c^2-(-2*b-2*a)c-b^2+2*a*b-a^2}{4*b*c}]$$$$x = [\frac{-\quad \frac{4*9}{7}^2-(-2*9-2*9)*-\quad \frac{4*9}{7}-9^2+2*9*9-9^2}{4*9*-\quad \frac{4*9}{7}}]$$\>$spread(a,a,4\*a/7)


$$\frac{6}{7}$$Ini adalah sudut dalam derajat.


\>degprint(arcsin(sqrt(6/7)))


    67°47'32.44''

## .

Sekarang, mari kita coba contoh yang lebih maju.


Kami mengatur tiga sudut segitiga sebagai berikut.


\>A&:=[1,2]; B&:=[4,3]; C&:=[0,4]; ...  
\>   setPlotRange(-1,5,1,5); ...  
\>   plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"); ...  
\>   plotSegment(B,A,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"); ...  
\>   insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-153.png](images/Afifah%20Setyaningsih_23030630009_Geometri-153.png)

Menggunakan Pythogoras, mudah untuk menghitung jarak antara dua titik.
Saya pertama kali menggunakan jarak fungsi file Euler untuk geometri.
Jarak fungsi menggunakan geometri klasik.


A=[1,2]; B=[4,3]; C=[0,4]


$$d= \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$$$d(A,B)= \sqrt{(4 - 1)^2 + (3 - 2)^2}$$$$d(A,B)= \sqrt{(3)^2 + (1)^2}$$$$d(A,B)= \sqrt{9 + 1}$$$$d(A,B)= \sqrt{10}$$\>$distance(A,B)


$$\sqrt{10}$$Euler juga mengandung fungsi untuk kuadran antara dua titik.


Dalam contoh berikut, karena c+b bukan a, maka segitiga itu bukan
persegi panjang.


A=[1,2]; B=[4,3]


$$d= \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$$$d(A,B)= \sqrt{(4 - 1)^2 + (3 - 2)^2}$$$$d(A,B)= \sqrt{(3)^2 + (1)^2}$$$$d(A,B)= \sqrt{9 + 1}$$$$d(A,B)= \sqrt{10}$$A=[1,2]; C=[0,4]


$$d= \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$$$d(A,C)= \sqrt{(0 - 1)^2 + (4 - 2)^2}$$$$d(A,C)= \sqrt{(-1)^2 + (2)^2}$$$$d(A,C)= \sqrt{1 + 4}$$$$d(A,C)= \sqrt{5}$$B=[4,3]; C=[0,4]


$$d= \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$$$d(B,C)= \sqrt{(0 - 4)^2 + (4 - 3)^2}$$$$d(B,C)= \sqrt{(-4)^2 + (1)^2}$$$$d(B,C)= \sqrt{16 + 1}$$$$d(B,C)= \sqrt{17}$$\>c &= quad(A,B); $c, b &= quad(A,C); $b, a &= quad(B,C); $a,


$$10$$$$5$$$$17$$Pertama, mari kita hitung sudut tradisional. Fungsi computeAngle
menggunakan metode biasa berdasarkan hasil kali titik dua vektor.
Hasilnya adalah beberapa pendekatan floating point.


$$A=<1,2>\quad B=<4,3>,\quad C=<0,4>$$$$\mathbf{a}=C-B=<-4,1>,\quad \mathbf{c}=A-B=<-3,-1>,\quad \beta=\angle ABC$$$$\mathbf{a}.\mathbf{c}=|\mathbf{a}|.|\mathbf{c}|\cos \beta$$$$\cos \angle ABC =\cos\beta=\frac{\mathbf{a}.\mathbf{c}}{|\mathbf{a}|.|\mathbf{c}|}=\frac{12-1}{\sqrt{17}\sqrt{10}}=\frac{11}{\sqrt{17}\sqrt{10}}$$\>wb &= computeAngle(A,B,C); $wb, $(wb/pi\*180)()


$$\arccos \left(\frac{11}{\sqrt{10}\,\sqrt{17}}\right)$$    32.4711922908

memasukkan kuadran a, b, dan c ke dalam hukum silang dan menyelesaikan
x.


$$(c+b-a)^2 = 4 b c \, (1-x)$$$$(10+5-17)^2 = 4*5*10 \, (1-x)$$$$(-2)^2 = 200 \, (1-x)$$$$4=200 (1 - x)$$$$x = \frac{49}{50}$$\>$crosslaw(a,b,c,x), $solve(%,x),


$$4=200\,\left(1-x\right)$$$$\left[ x=\frac{49}{50} \right] $$Yaitu, apa yang dilakukan oleh penyebaran fungsi yang didefinisikan
dalam "geometry.e".


pengukuran penyebaran antara nilai-nilai b, a, dan c.


$$x = [\frac{-c^2-(-2*a-2*b)c-a^2+2*b*a-b^2}{4*a*c}]$$$$x = [\frac{-10^2-(-2*17-2*5)10-17^2+2*5*17-5^2}{4*17*10}]$$$$x = [\frac{-100-(-34-10)10-289+170-25}{680}]$$$$x = [\frac{-100-(-440)-425}{680}]$$$$x = [\frac{765}{680}]$$$$x = [\frac{49}{170}]$$\>sb &= spread(b,a,c); $sb


$$\frac{49}{170}$$Maxima mendapatkan hasil yang sama menggunakan trigonometri biasa, .
Itu menyelesaikan istilah sin(arccos(...)) menjadi hasil pecahan.


\>$sin(computeAngle(A,B,C))^2


$$\frac{49}{170}$$Setelah kita memiliki spread di B, kita dapat menghitung tinggi ha di
sisi a. Ingat bahwa


$$s_b=\frac{h_a}{c}$$$$h_a=c*s_b$$Menurut definisi.


\>ha &= c\*sb; $ha


$$\frac{49}{17}$$Gambar berikut telah dihasilkan dengan program geometri C.a.R., yang
dapat menggambar kuadrat dan menyebar.


image: (20) Rational_Geometry_CaR.png


Menurut definisi, panjang ha adalah akar kuadrat dari kuadratnya.


$$\sqrt{ha}=\sqrt{\frac{49}{17}}$$$$=\frac{7}{\sqrt{17}}$$\>$sqrt(ha)


$$\frac{7}{\sqrt{17}}$$Sekarang kita dapat menghitung luas segitiga. Jangan lupa, bahwa kita
berhadapan dengan kuadrat!


Menghitung Luas Segitiga


a=17; b=5; c=10


$$\sqrt{ha}*\frac{\sqrt{a}}{2}$$$$\frac{7}{\sqrt{17}} * \frac{\sqrt{17}}{2}$$$$\frac{7}{2}$$\>$sqrt(ha)\*sqrt(a)/2


$$\frac{7}{2}$$Rumus determinan biasa menghasilkan hasil yang sama.


A&amp;:=[1,2]; B&amp;:=[4,3]; C&amp;:=[0,4]


$$Luas = \frac{1}{2}\vert{Det}\vert$$$$Luas = \frac{1}{2}\vert{\left[\begin{matrix}x_1 & y_1 & 1 \\x_2 & y_2 & 1\\x_3 & y_3 & 1\end{matrix}\right]}\vert$$$$Det = \left[\begin{matrix}1 & 2 & 1 \\4 & 3 & 1\\0 & 4 & 1\end{matrix}\right]$$$$Det = 1 * \left[\begin{matrix}3 & 1\\4 & 1\end{matrix}\right] -2 * \left[\begin{matrix}4 & 1\\0 & 1\end{matrix}\right] + 1* \left[\begin{matrix}4 & 3\\0 & 4\end{matrix}\right]$$$$Det = 1*(-1)-2*(4)+1(16)$$$$Det = -1-8+16$$$$Det = 7$$$$Luas = \frac{1}{2}\vert{Det}\vert$$$$Luas = \frac{1}{2}\vert{7}\vert$$$$Luas = \frac{7}{2}$$\>$areaTriangle(B,A,C)


$$\frac{7}{2}$$# Aturan Triple Spread

Kerugian dari spread adalah mereka tidak lagi hanya menambahkan sudut
yang sama.


Namun, tiga spread dari sebuah segitiga memenuhi aturan "triple
spread" berikut.


\>&remvalue(sa,sb,sc); $triplespread(sa,sb,sc)


$$\left({\it sc}+{\it sb}+{\it sa}\right)^2=2\,\left({\it sc}^2+
 {\it sb}^2+{\it sa}^2\right)+4\,{\it sa}\,{\it sb}\,{\it sc}$$Aturan ini berlaku untuk setiap tiga sudut yang menambah 180 °.


$$\alpha+\beta+\gamma=\pi$$Sejak menyebar


$$\alpha, \pi-\alpha$$sama, aturan triple spread juga benar, jika


$$\alpha+\beta=\gamma$$Karena penyebaran sudut negatif adalah sama, aturan penyebaran rangkap
tiga juga berlaku, jika


$$\alpha+\beta+\gamma=0$$Misalnya, kita dapat menghitung penyebaran sudut 60°. Ini 3/4.
Persamaan memiliki solusi kedua, bagaimanapun, di mana semua spread
adalah 0.


\>$solve(triplespread(x,x,x),x)


$$\left[ x=\frac{3}{4} , x=0 \right] $$Sebaran 90° jelas 1. Jika dua sudut dijumlahkan menjadi 90°,
sebarannya menyelesaikan persamaan sebaran rangkap tiga dengan a,b,1.
Dengan perhitungan berikut kita mendapatkan a+b=1.


\>$triplespread(x,y,1), $solve(%,x)


$$\left(y+x+1\right)^2=2\,\left(y^2+x^2+1\right)+4\,x\,y$$$$\left[ x=1-y \right] $$Karena sebaran 180°-t sama dengan sebaran t, rumus sebaran rangkap
tiga juga berlaku, jika satu sudut adalah jumlah atau selisih dua
sudut lainnya.


Jadi kita dapat menemukan penyebaran sudut berlipat ganda. Perhatikan
bahwa ada dua solusi lagi. Kami membuat ini fungsi.


\>$solve(triplespread(a,a,x),x), function doublespread(a) &= factor(rhs(%[1]))


$$\left[ x=-1088 , x=0 \right] $$    
                                    - 1088
    

# Sudut Pembagi

Ini situasinya, kita sudah tahu.


\>C&:=[0,0]; A&:=[4,0]; B&:=[0,3]; ...  
\>   setPlotRange(-1,5,-1,5); ...  
\>   plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"); ...  
\>   plotSegment(B,A,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"); ...  
\>   insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-228.png](images/Afifah%20Setyaningsih_23030630009_Geometri-228.png)

Mari kita hitung panjang garis bagi sudut di A. Tetapi kita ingin
menyelesaikannya untuk umum a,b,c.


\>&remvalue(a,b,c);


Jadi pertama-tama kita hitung penyebaran sudut yang dibagi dua di A,
dengan menggunakan rumus sebaran rangkap tiga.


Masalah dengan rumus ini muncul lagi. Ini memiliki dua solusi. Kita
harus memilih yang benar. Solusi lainnya mengacu pada sudut terbelah
180 °-wa.


\>$triplespread(x,x,a/(a+b)), $solve(%,x), sa2 &= rhs(%[1]); $sa2


$$\left(2\,x+\frac{a}{b+a}\right)^2=2\,\left(2\,x^2+\frac{a^2}{\left(
 b+a\right)^2}\right)+\frac{4\,a\,x^2}{b+a}$$$$\left[ x=\frac{-\sqrt{b}\,\sqrt{b+a}+b+a}{2\,b+2\,a} , x=\frac{
 \sqrt{b}\,\sqrt{b+a}+b+a}{2\,b+2\,a} \right] $$$$\frac{-\sqrt{b}\,\sqrt{b+a}+b+a}{2\,b+2\,a}$$Mari kita periksa persegi panjang Mesir.


$$\frac{-\sqrt{b^2+ab}+b+a}{2b+2a}$$$$=\frac{-\sqrt{16^2+9*16}+16+9}{2*16+2*9}$$$$=\frac{-\sqrt{256+144}+25}{32+18}$$$$=\frac{-\sqrt{400}+25}{50}$$$$=\frac{-20+25}{50}$$$$=\frac{5}{50}$$$$=\frac{1}{10}$$\>$sa2 with [a=3^2,b=4^2]


$$\frac{1}{10}$$Kami dapat mencetak sudut dalam Euler, setelah mentransfer penyebaran
ke radian.


\>wa2 := arcsin(sqrt(1/10)); degprint(wa2)


    18°26'5.82''

Titik P adalah perpotongan garis bagi sudut dengan sumbu y.


\>P := [0,tan(wa2)\*4]


    [0,  1.33333]

\>plotPoint(P,"P"); plotSegment(A,P):


![images/Afifah%20Setyaningsih_23030630009_Geometri-240.png](images/Afifah%20Setyaningsih_23030630009_Geometri-240.png)

Mari kita periksa sudut dalam contoh spesifik kita.


\>computeAngle(C,A,P), computeAngle(P,A,B)


    0.321750554397
    0.321750554397

Sekarang kita hitung panjang garis bagi AP.


Kami menggunakan teorema sinus dalam segitiga APC. Teorema ini
menyatakan bahwa


$$\frac{BC}{\sin(w_a)} = \frac{AC}{\sin(w_b)} = \frac{AB}{\sin(w_c)}$$berlaku dalam segitiga apa pun. Kuadratkan, itu diterjemahkan ke dalam
apa yang disebut "hukum penyebaran"


$$\frac{a}{s_a} = \frac{b}{s_b} = \frac{c}{s_b}$$di mana a,b,c menunjukkan qudrances.


Karena spread CPA adalah 1-sa2, kita dapatkan darinya bisa/1=b/(1-sa2)
dan dapat menghitung bisa (kuadran dari garis-bagi sudut).


\>&factor(ratsimp(b/(1-sa2))); bisa &= %; $bisa


$$\frac{2\,b\,\left(b+a\right)}{\sqrt{b}\,\sqrt{b+a}+b+a}$$Mari kita periksa rumus ini untuk nilai-nilai Mesir kita.


\>sqrt(mxmeval("at(bisa,[a=3^2,b=4^2])")), distance(A,P)


    4.21637021356
    4.21637021356

Kita juga dapat menghitung P menggunakan rumus spread.


\>py&=factor(ratsimp(sa2\*bisa)); $py


$$-\frac{b\,\left(\sqrt{b}\,\sqrt{b+a}-b-a\right)}{\sqrt{b}\,\sqrt{b+
 a}+b+a}$$Nilainya sama dengan yang kita dapatkan dengan rumus trigonometri.


\>sqrt(mxmeval("at(py,[a=3^2,b=4^2])"))


    1.33333333333

## Sudut Akord

Mengantur rentang tampilan plot 


\>setPlotRange(1.2):


![images/Afifah%20Setyaningsih_23030630009_Geometri-245.png](images/Afifah%20Setyaningsih_23030630009_Geometri-245.png)

Menggambar lingkaran pada grafik 


\>color(1); plotCircle(circleWithCenter([0,0],1)):


![images/Afifah%20Setyaningsih_23030630009_Geometri-246.png](images/Afifah%20Setyaningsih_23030630009_Geometri-246.png)

Mendefinisikan koordinat titik A,B, dan C 


\>A:=[cos(1),sin(1)]; B:=[cos(2),sin(2)]; C:=[cos(6),sin(6)];


maka koordinat titik A,B,C


A:[0.540302,0.841471]


B:[-0.416147,0.909297]


C:[0.96017,-0.279415]


Menampilkan titik A,B,C pada grafik


\>plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-247.png](images/Afifah%20Setyaningsih_23030630009_Geometri-247.png)

Menghubungkan titik-titik ABC 


\>color(3); plotSegment(A,B,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-248.png](images/Afifah%20Setyaningsih_23030630009_Geometri-248.png)

Menggambar titik di pusat koordinat 


\>color(1); O:=[0,0];  plotPoint(O,"O"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-249.png](images/Afifah%20Setyaningsih_23030630009_Geometri-249.png)

Menghubungkan masing-masing titik ABC ke titik pusat (O) 


\>plotSegment(A,O); plotSegment(B,O); plotSegment(C,O,"r"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-250.png](images/Afifah%20Setyaningsih_23030630009_Geometri-250.png)

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-251.png](images/Afifah%20Setyaningsih_23030630009_Geometri-251.png)

Kita dapat menggunakan Maxima untuk menyelesaikan rumus penyebaran
dari sebuah segitiga rangkap tiga untuk sudut-sudut di pusat O untuk
r.


Menghapus nilai-nilai variabel sebelumnya


\>&remvalue(a,b,c,r); // hapus nilai-nilai sebelumnya untuk perhitungan baru


Menentukan jari-jari keliling (circumradius) dari segitiga 


\>rabc &= rhs(solve(triplespread(spread(b,r,r),spread(a,r,r),spread(c,r,r)),r)[4]); $rabc


$$-\frac{a\,b\,c}{c^2-2\,b\,c+a\,\left(-2\,c-2\,b\right)+b^2+a^2}$$Kita dapat menjadikannya sebagai fungsi Euler.


\>function periradius(a,b,c) &= rabc;


Mari kita periksa hasilnya untuk poin A,B,C.


\>a:=quadrance(B,C); b:=quadrance(A,C); c:=quadrance(A,B);


Jari-jari lingkaran keliling (circumcircle) dari sebuah segitiga


\>periradius(a,b,c)


    1

Faktanya adalah , bahwa penyebaran CBA hanya bergantung pada b dan c.
Ini adalah teorema sudut akor.


\>$spread(b,a,c)\*rabc | ratsimp


$$\frac{b}{4}$$Faktanya penyebarannya adalah b/(4r), dan kita melihat bahwa sudut
chord b adalah setengah dari sudut pusat.


\>$doublespread(b/(4\*r))-spread(b,r,r) | ratsimp


$$\frac{-4352\,r^2-4\,b\,r+b^2}{4\,r^2}$$# Jarak Minimal pada Bidang

## Fungsi Jarak dan Kurva Level

Fungsi ini menggambarkan jarak antara dua titik dalam bidang, di mana
A adalah titik tetap dan M adalah titik yang bergerak. Dinyatakan
bahwa fungsi yang menetapkan jarak antara titik tetap A dan titik lain
M di bidang akan menghasilkan garis level yang berupa lingkaran yang
berpusat di A. Artinya, setiap titik yang berada di lingkaran tersebut
memiliki jarak yang sama dari titik A.


Fungsi ini juga memvisualisasikan konsep bahwa jarak dari titik tetap
ke berbagai titik lainnya bisa dilihat sebagai pola lingkaran di
sekitar titik tetap.


Menghapus atau mereset variabel atau nilai sebelumnya agar tidak
mengganggu perhitungan yang akan dilakukan.


\>&remvalue();


Mendefinisikan titik tetap A


\>A=[-1,-1];


Jarak antara titik (x,y) dan titik tetap A menggunakan rumus jarak
Euclidean


\>function d1(x,y):=sqrt((x-A[1])^2+(y-A[2])^2)


Grafik kontur dari fungsi d1


\>fcontour("d1",xmin=-2,xmax=0,ymin=-2,ymax=0,hue=1, ...  
\>   title="If you see ellipses, please set your window square"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-255.png](images/Afifah%20Setyaningsih_23030630009_Geometri-255.png)

Pada grafik kontur diatas, kita dapat melihat lingkaran-lingkaran yang
mengelilingi titik A, dimana setiap lingkaran mewakili jarak yang sama
dari A.


Grafik 3D dari fungsi d1


\>plot3d("d1",xmin=-2,xmax=0,ymin=-2,ymax=0):


![images/Afifah%20Setyaningsih_23030630009_Geometri-256.png](images/Afifah%20Setyaningsih_23030630009_Geometri-256.png)

Grafik tersebut menunjukkan bentuk 3D dari jarak di mana puncak (atas)
kerucut akan menjadi titik A dan jarak ke titik M lainnya digambarkan
sebagai ketinggian dari permukaan. Bagian atas kerucut ini membantu
memahami bagaimana jarak meningkat ketika bergerak lebih jauh dari
titik pusat A.


## Ellips sebagai Kurva Level untuk Dua Titik

Penjelasan mengenai fungsi MA+MB menggambarkan bahwa fungsi yang
sedang dianalisis adalah penjumlahan jarak dari titik M ke dua titik
tetap, yaitu A dan B. Jika semua titik M diambil sedemikian rupa
sehingga jumlah jarak dari A dan B tetap konstan, maka kurva yang
terbentuk adalah elips dengan A dan B sebagai titik fokusnya. Dalam
konteks ini, kurva level dari fungsi tersebut adalah elips, kecuali
ketika jarak antara A dan B berada pada nilai minimum yang tetap, yang
menggambarkan jarak terpendek pada segmen [AB]


Mendefinisikan titik B


\>B=[1,-1];


Jarak dari titik (x,y) ke titik tetap A dan B 


\>function d2(x,y):=d1(x,y)+sqrt((x-B[1])^2+(y-B[2])^2)


Grafik kontur dari fungsi d2


\>fcontour("d2",xmin=-2,xmax=2,ymin=-3,ymax=1,hue=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-257.png](images/Afifah%20Setyaningsih_23030630009_Geometri-257.png)

Menghasilkan gambar ellips di mana setiap garis kontur menunjukkan
lokasi titik M yang memiliki jumlah jarak yang sama ke A dan B


Grafik 3D dari fungsi d2


\>plot3d("d2",xmin=-2,xmax=2,ymin=-3,ymax=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-258.png](images/Afifah%20Setyaningsih_23030630009_Geometri-258.png)

Menghasilkan grafik 3D dari fungsi d2 di mana titik-titik pada
permukaan mewakili jarak total dari suatu titik M ke A dan B.


Garis pembatas antara titik A dan B


\>plot2d("abs(x+1)+abs(x-1)",xmin=-3,xmax=3):


![images/Afifah%20Setyaningsih_23030630009_Geometri-259.png](images/Afifah%20Setyaningsih_23030630009_Geometri-259.png)

mensubtitusikan nilai x=-3 dan x=3


$$f(x)=\vert{x+1}\vert + \vert{x-1}\vert$$

ketika x=-3


$$f(-3)=\vert{(-3)+1}\vert + \vert{(-3)-1}\vert$$$$f(-3)=\vert{-2}\vert + \vert{-4}\vert$$$$f(-3)=2+4$$$$f(-3)=6$$ketika x=3


$$f(3)=\vert{3+1}\vert + \vert{3-1}\vert$$$$f(3)=\vert{4}\vert + \vert{2}\vert$$$$f(3)=4+2$$$$f(3)=6$$Jadi, pada saat x=-3 dan x=3, nilai fungsi mencapai 6.


## Penentuan Jarak Minimal untuk Tiga Titik : Titik Fermat

Terdapat tantangan dalam menemukan titik yang meminimalkan jumlah
jarak dari tiga titik sudut segitiga (MA+MB+MC) ke satu titik di dalam
atau di sekitar segitiga. Walaupun mungkin secara umum diketahui bahwa
jumlah jarak ini mencapai nilai minimum di satu titik tertentu, proses
untuk menentukan titik ini tidak sesederhana kelihatannya.


1) Kasus Sudut Besar (lebih dari 120°)


Jika salah satu sudut dari segitiga ABC lebih besar dari 120°
(misalnya di titik A), maka jarak minimum dicapai di titik
tersebut(misalnya AB+AC). Hal ini berarti, dalam kasus seperti ini,
titik Fermat berada di salah satu sudut segitiga.


Contoh:


Mendefinisikan titik C


\>C=[-4,1];


Jarak dari titik (x,y) ke titik A,B,dan C 


\>function d3(x,y):=d2(x,y)+sqrt((x-C[1])^2+(y-C[2])^2)


Grafik 3D dari fungsi d3


\>plot3d("d3",xmin=-5,xmax=3,ymin=-4,ymax=4);

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-269.png](images/Afifah%20Setyaningsih_23030630009_Geometri-269.png)

Grafik kontur dari fungsi d3


\>fcontour("d3",xmin=-4,xmax=1,ymin=-2,ymax=2,hue=1,title="The minimum is on A"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-270.png](images/Afifah%20Setyaningsih_23030630009_Geometri-270.png)

Grafik kontur tersebut menunjukkan bahwa titik minimum (jarak total
terkecil) berada di titik sudut A dari segitiga.


Menggambar Segitiga ABC


\>P=(A\_B\_C\_A)'; plot2d(P[1],P[2],add=1,color=12):


![images/Afifah%20Setyaningsih_23030630009_Geometri-271.png](images/Afifah%20Setyaningsih_23030630009_Geometri-271.png)

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-272.png](images/Afifah%20Setyaningsih_23030630009_Geometri-272.png)

2. Kasus Sudut Kecil (kurang dari 120°)


Jika semua sudut segitiga ABC kurang dari 120°, maka jarak minimum
dari tiga titik akan dicapai pada titik F di bagian dalam segitiga,
yang merupakan satu-satunya titik yang melihat sisi-sisi ABC dengan
sudut yang sama (maka masing-masing 120°)


Mendefinisikan titik C


\>C=[-0.5,1];


Grafik 3D dari fungsi d3


\>plot3d("d3",xmin=-2,xmax=2,ymin=-2,ymax=2):


![images/Afifah%20Setyaningsih_23030630009_Geometri-273.png](images/Afifah%20Setyaningsih_23030630009_Geometri-273.png)

Grafik kontur dari fungsi d3


\>fcontour("d3",xmin=-2,xmax=2,ymin=-2,ymax=2,hue=1,title="The Fermat point"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-274.png](images/Afifah%20Setyaningsih_23030630009_Geometri-274.png)

Menggambar segitiga ABC


\>P=(A\_B\_C\_A)'; plot2d(P[1],P[2],add=1,color=12):


![images/Afifah%20Setyaningsih_23030630009_Geometri-275.png](images/Afifah%20Setyaningsih_23030630009_Geometri-275.png)

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-276.png](images/Afifah%20Setyaningsih_23030630009_Geometri-276.png)

Semua ini di atas telah ditemukan oleh seorang hakim Perancis bernama
Pierre de Fermat, yang menulis tentang hal ini kepada ilmuwan lain
pada zamannya. Titik Fermat secara geometris meminimalkan jumlah jarak
dari tiga sudut segitiga. Meskipun Fermat dianggap sebagai penemunya,
beberapa ilmuwan lain mungkin telah nememukannya lebih awal, seperti
Torricelli di Italia.


## Optimasi Jarak pada Empat Titik : Kasus Jaringan Kabel

Langkah selanjutnya adalah menambahkan titik keempat, titik D dan
mencoba meminimalkan MA+MB+MC+MD; misalkan anda adalah operator TV
kabel dan ingin menemukan lokasi yang tepat untuk menempatkan antena
agar dapat melayani empat desa dengan panjang kabel seminimal mungkin!


Mendefinisikan titik D


\>D=[1,1];


Jarak titik (x,y) ke titik A,B,C,D 


\>function d4(x,y):=d3(x,y)+sqrt((x-D[1])^2+(y-D[2])^2)


Grafik 3D dari fungsi d4


\>plot3d("d4",xmin=-1.5,xmax=1.5,ymin=-1.5,ymax=1.5):


![images/Afifah%20Setyaningsih_23030630009_Geometri-277.png](images/Afifah%20Setyaningsih_23030630009_Geometri-277.png)

Grafik kontur dari fungsi d4


\>fcontour("d4",xmin=-1.5,xmax=1.5,ymin=-1.5,ymax=1.5,hue=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-278.png](images/Afifah%20Setyaningsih_23030630009_Geometri-278.png)

Mengeplot titik ABCD dalam grafik 2D


\>P=(A\_B\_C\_D)'; plot2d(P[1],P[2],points=1,add=1,color=12):


![images/Afifah%20Setyaningsih_23030630009_Geometri-279.png](images/Afifah%20Setyaningsih_23030630009_Geometri-279.png)

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-280.png](images/Afifah%20Setyaningsih_23030630009_Geometri-280.png)

Titik simpul tidak berada di salah satu simpul A,B,C atau D, melainkan
di suatu titik lain di dalam area tersebut


Jarak dari titik (x,y) ke titik A,B,C,D


\>function f(x):=d4(x[1],x[2])


Mencari titik minimum dari fungsi f dengan metode Nelder-Mead 


\>neldermin("f",[0.2,0.2])


    [0.142858,  0.142857]

Tampaknya, dalam kasus ini, koordinat titik optimal merupakan bilangan
rasional atau setidaknya mendekati rasional


Sekarang, kita menganggap ABCD sebagai sebuah persegi, dan kita
berharap titik optimalnya akan berada tepat di tengah-tengah persegi
ABCD tersebut.


Mendefinisikan titik C


\>C=[-1,1];


Grafik 3D dari fungsi d4


\>plot3d("d4",xmin=-1,xmax=1,ymin=-1,ymax=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-281.png](images/Afifah%20Setyaningsih_23030630009_Geometri-281.png)

Grafik kontur dari fungsi d4


\>fcontour("d4",xmin=-1.5,xmax=1.5,ymin=-1.5,ymax=1.5,hue=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-282.png](images/Afifah%20Setyaningsih_23030630009_Geometri-282.png)

Mengeplot titik ABCD ke dalam grafik 2D


\>P=(A\_B\_C\_D)'; plot2d(P[1],P[2],add=1,color=12,points=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-283.png](images/Afifah%20Setyaningsih_23030630009_Geometri-283.png)

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-284.png](images/Afifah%20Setyaningsih_23030630009_Geometri-284.png)

# Bola Dandelin dengan Povray

Anda dapat menjalankan demonstrasi ini, jika Anda telah menginstal
Povray, dan pvengine.exe di jalur program.


Pertama kita hitung jari-jari bola.


Jika Anda melihat gambar di bawah, Anda melihat bahwa kita membutuhkan
dua lingkaran yang menyentuh dua garis yang membentuk kerucut, dan
satu garis yang membentuk bidang yang memotong kerucut.


Kami menggunakan file geometri.e dari Euler untuk ini.


\>load geometry;


Pertama dua garis yang membentuk kerucut.


\>g1 &= lineThrough([0,0],[1,a])


    
                                 [- a, 1, 0]
    

\>g2 &= lineThrough([0,0],[-1,a])


    
                                [- a, - 1, 0]
    

Kemudian baris ketiga.


\>g &= lineThrough([-1,0],[1,1])


    
                                 [- 1, 2, 1]
    

Kami merencanakan semuanya sejauh ini.


\>setPlotRange(-1,1,0,2);

\>color(black); plotLine(g(),"")

\>a:=2; color(blue); plotLine(g1(),""), plotLine(g2(),""):


![images/Afifah%20Setyaningsih_23030630009_Geometri-285.png](images/Afifah%20Setyaningsih_23030630009_Geometri-285.png)

Sekarang kita ambil titik umum pada sumbu y.


\>P &= [0,u]


    
                                    [0, u]
    

Hitung jarak ke g1.


\>d1 &= distance(P,projectToLine(P,g1)); $d1


$$\sqrt{\left(\frac{a^2\,u}{a^2+1}-u\right)^2+\frac{a^2\,u^2}{\left(a
 ^2+1\right)^2}}$$Hitung jarak ke g.


\>d &= distance(P,projectToLine(P,g)); $d


$$\sqrt{\left(\frac{u+2}{5}-u\right)^2+\frac{\left(2\,u-1\right)^2}{
 25}}$$Dan temukan pusat kedua lingkaran yang jaraknya sama.


\>sol &= solve(d1^2=d^2,u); $sol


$$\left[ u=\frac{-\sqrt{5}\,\sqrt{a^2+1}+2\,a^2+2}{4\,a^2-1} , u=
 \frac{\sqrt{5}\,\sqrt{a^2+1}+2\,a^2+2}{4\,a^2-1} \right] $$Ada dua solusi.


Kami mengevaluasi solusi simbolis, dan menemukan kedua pusat, dan
kedua jarak.


\>u := sol()


    [0.333333,  1]

\>dd := d()


    [0.149071,  0.447214]

Plot lingkaran ke dalam gambar.


\>color(red);

\>plotCircle(circleWithCenter([0,u[1]],dd[1]),"");

\>plotCircle(circleWithCenter([0,u[2]],dd[2]),"");

\>insimg;


![images/Afifah%20Setyaningsih_23030630009_Geometri-289.png](images/Afifah%20Setyaningsih_23030630009_Geometri-289.png)

## Plot dengan Povray

Selanjutnya kami merencanakan semuanya dengan Povray. Perhatikan bahwa
Anda mengubah perintah apa pun dalam urutan perintah Povray berikut,
dan menjalankan kembali semua perintah dengan Shift-Return.


Pertama kita memuat fungsi povray.


\>load povray;

\>defaultpovray="C:\\Program Files\\POV-Ray\\v3.7\\bin\\pvengine.exe"


    C:\Program Files\POV-Ray\v3.7\bin\pvengine.exe

Kami mengatur adegan dengan tepat.


\>povstart(zoom=11,center=[0,0,0.5],height=10°,angle=140°);


Selanjutnya kita menulis dua bidang ke file Povray.


\>writeln(povsphere([0,0,u[1]],dd[1],povlook(red)));

\>writeln(povsphere([0,0,u[2]],dd[2],povlook(red)));


Dan kerucutnya, transparan.


\>writeln(povcone([0,0,0],0,[0,0,a],1,povlook(lightgray,1)));


Kami menghasilkan bidang terbatas pada kerucut.


\>gp=g();

\>pc=povcone([0,0,0],0,[0,0,a],1,"");

\>vp=[gp[1],0,gp[2]]; dp=gp[3];

\>writeln(povplane(vp,dp,povlook(blue,0.5),pc));


Sekarang kita menghasilkan dua titik pada lingkaran, di mana bola
menyentuh kerucut.


\>function turnz(v) := return [-v[2],v[1],v[3]]

\>P1=projectToLine([0,u[1]],g1()); P1=turnz([P1[1],0,P1[2]]);

\>writeln(povpoint(P1,povlook(yellow)));

\>P2=projectToLine([0,u[2]],g1()); P2=turnz([P2[1],0,P2[2]]);

\>writeln(povpoint(P2,povlook(yellow)));


Kemudian kami menghasilkan dua titik di mana bola menyentuh bidang.
Ini adalah fokus dari elips.


\>P3=projectToLine([0,u[1]],g()); P3=[P3[1],0,P3[2]];

\>writeln(povpoint(P3,povlook(yellow)));

\>P4=projectToLine([0,u[2]],g()); P4=[P4[1],0,P4[2]];

\>writeln(povpoint(P4,povlook(yellow)));


Selanjutnya kita hitung perpotongan P1P2 dengan bidang.


\>t1=scalp(vp,P1)-dp; t2=scalp(vp,P2)-dp; P5=P1+t1/(t1-t2)\*(P2-P1);

\>writeln(povpoint(P5,povlook(yellow)));


Kami menghubungkan titik-titik dengan segmen garis.


\>writeln(povsegment(P1,P2,povlook(yellow)));

\>writeln(povsegment(P5,P3,povlook(yellow)));

\>writeln(povsegment(P5,P4,povlook(yellow)));


Sekarang kita menghasilkan pita abu-abu, di mana bola menyentuh
kerucut.


\>pcw=povcone([0,0,0],0,[0,0,a],1.01);

\>pc1=povcylinder([0,0,P1[3]-defaultpointsize/2],[0,0,P1[3]+defaultpointsize/2],1);

\>writeln(povintersection([pcw,pc1],povlook(gray)));

\>pc2=povcylinder([0,0,P2[3]-defaultpointsize/2],[0,0,P2[3]+defaultpointsize/2],1);

\>writeln(povintersection([pcw,pc2],povlook(gray)));


Mulai program Povray.


\>povend();


![images/Afifah%20Setyaningsih_23030630009_Geometri-290.png](images/Afifah%20Setyaningsih_23030630009_Geometri-290.png)

Untuk mendapatkan Anaglyph ini kita perlu memasukkan semuanya ke dalam
fungsi scene. Fungsi ini akan digunakan dua kali kemudian.


\>function scene () ...


    global a,u,dd,g,g1,defaultpointsize;
    writeln(povsphere([0,0,u[1]],dd[1],povlook(red)));
    writeln(povsphere([0,0,u[2]],dd[2],povlook(red)));
    writeln(povcone([0,0,0],0,[0,0,a],1,povlook(lightgray,1)));
    gp=g();
    pc=povcone([0,0,0],0,[0,0,a],1,"");
    vp=[gp[1],0,gp[2]]; dp=gp[3];
    writeln(povplane(vp,dp,povlook(blue,0.5),pc));
    P1=projectToLine([0,u[1]],g1()); P1=turnz([P1[1],0,P1[2]]);
    writeln(povpoint(P1,povlook(yellow)));
    P2=projectToLine([0,u[2]],g1()); P2=turnz([P2[1],0,P2[2]]);
    writeln(povpoint(P2,povlook(yellow)));
    P3=projectToLine([0,u[1]],g()); P3=[P3[1],0,P3[2]];
    writeln(povpoint(P3,povlook(yellow)));
    P4=projectToLine([0,u[2]],g()); P4=[P4[1],0,P4[2]];
    writeln(povpoint(P4,povlook(yellow)));
    t1=scalp(vp,P1)-dp; t2=scalp(vp,P2)-dp; P5=P1+t1/(t1-t2)*(P2-P1);
    writeln(povpoint(P5,povlook(yellow)));
    writeln(povsegment(P1,P2,povlook(yellow)));
    writeln(povsegment(P5,P3,povlook(yellow)));
    writeln(povsegment(P5,P4,povlook(yellow)));
    pcw=povcone([0,0,0],0,[0,0,a],1.01);
    pc1=povcylinder([0,0,P1[3]-defaultpointsize/2],[0,0,P1[3]+defaultpointsize/2],1);
    writeln(povintersection([pcw,pc1],povlook(gray)));
    pc2=povcylinder([0,0,P2[3]-defaultpointsize/2],[0,0,P2[3]+defaultpointsize/2],1);
    writeln(povintersection([pcw,pc2],povlook(gray)));
    endfunction
</pre>
Anda membutuhkan kacamata merah/sian untuk menghargai efek berikut.


\>povanaglyph("scene",zoom=11,center=[0,0,0.5],height=10°,angle=140°);


![images/Afifah%20Setyaningsih_23030630009_Geometri-291.png](images/Afifah%20Setyaningsih_23030630009_Geometri-291.png)

# Geometri Bumi

Dalam buku catatan ini, kami ingin melakukan beberapa perhitungan
sferis. Fungsi-fungsi tersebut terdapat dalam file "spherical.e" di
folder contoh. Kita perlu memuat file itu terlebih dahulu.


\>load "spherical.e";


Untuk memasukkan posisi geografis, kami menggunakan vektor dengan dua
koordinat dalam radian (utara dan timur, nilai negatif untuk selatan
dan barat). Berikut koordinat Kampus FMIPA UNY.


\>FMIPA=[rad(-7,-46.467),rad(110,23.05)]


    [-0.13569,  1.92657]

Anda dapat mencetak posisi ini dengan sposprint (cetak posisi
spherical).


\>sposprint(FMIPA) // posisi garis lintang dan garis bujur FMIPA UNY


    S 7°46.467' E 110°23.050'

Mari kita tambahkan dua kota lagi, Solo dan Semarang.


\>Solo=[rad(-7,-34.333),rad(110,49.683)]; Semarang=[rad(-6,-59.05),rad(110,24.533)];

\>sposprint(Solo), sposprint(Semarang),


    S 7°34.333' E 110°49.683'
    S 6°59.050' E 110°24.533'

Pertama kita menghitung vektor dari satu ke yang lain pada bola ideal.
Vektor ini [pos,jarak] dalam radian. Untuk menghitung jarak di bumi,
kita kalikan dengan jari-jari bumi pada garis lintang 7°.


\>br=svector(FMIPA,Solo); degprint(br[1]), br[2]\*rearth(7°)-\>km // perkiraan jarak FMIPA-Solo


    65°20'26.60''
    53.8945384608

Ini adalah perkiraan yang baik. Rutinitas berikut menggunakan
perkiraan yang lebih baik. Pada jarak yang begitu pendek hasilnya
hampir sama.


\>esdist(FMIPA,Semarang)-\>" km", // perkiraan jarak FMIPA-Semarang


    88.0114026318 km

Ada fungsi untuk heading, dengan mempertimbangkan bentuk elips bumi.
Sekali lagi, kami mencetak dengan cara yang canggih.


\>sdegprint(esdir(FMIPA,Solo))


         65.34°

Sudut segitiga melebihi 180° pada bola.


\>asum=sangle(Solo,FMIPA,Semarang)+sangle(FMIPA,Solo,Semarang)+sangle(FMIPA,Semarang,Solo); degprint(asum)


    180°0'10.77''

Ini dapat digunakan untuk menghitung luas segitiga. Catatan: Untuk
segitiga kecil, ini tidak akurat karena kesalahan pengurangan dalam
asum-pi.


\>(asum-pi)\*rearth(48°)^2-\>" km^2", // perkiraan luas segitiga FMIPA-Solo-Semarang,


    2116.02948749 km^2

Ada fungsi untuk ini, yang menggunakan garis lintang rata-rata
segitiga untuk menghitung jari-jari bumi, dan menangani kesalahan
pembulatan untuk segitiga yang sangat kecil.


\>esarea(Solo,FMIPA,Semarang)-\>" km^2", //perkiraan yang sama dengan fungsi esarea()


    2123.64310526 km^2

Kita juga dapat menambahkan vektor ke posisi. Sebuah vektor berisi
heading dan jarak, keduanya dalam radian. Untuk mendapatkan vektor,
kami menggunakan vektor. Untuk menambahkan vektor ke posisi, kami
menggunakan vektor sadd.


\>v=svector(FMIPA,Solo); sposprint(saddvector(FMIPA,v)), sposprint(Solo),


    S 7°34.333' E 110°49.683'
    S 7°34.333' E 110°49.683'

Fungsi-fungsi ini mengasumsikan bola yang ideal. Hal yang sama di
bumi.


\>sposprint(esadd(FMIPA,esdir(FMIPA,Solo),esdist(FMIPA,Solo))), sposprint(Solo),


    S 7°34.333' E 110°49.683'
    S 7°34.333' E 110°49.683'

Mari kita beralih ke contoh yang lebih besar, Tugu Jogja dan Monas
Jakarta (menggunakan Google Earth untuk mencari koordinatnya).


\>Tugu=[-7.7833°,110.3661°]; Monas=[-6.175°,106.811944°];

\>sposprint(Tugu), sposprint(Monas)


    S 7°46.998' E 110°21.966'
    S 6°10.500' E 106°48.717'

Menurut Google Earth, jaraknya adalah 429,66 km. Kami mendapatkan
pendekatan yang baik.


\>esdist(Tugu,Monas)-\>" km", // perkiraan jarak Tugu Jogja - Monas Jakarta


    431.565659488 km

Judulnya sama dengan judul yang dihitung di Google Earth.


\>degprint(esdir(Tugu,Monas))


    294°17'2.85''

Namun, kita tidak lagi mendapatkan posisi target yang tepat, jika kita
menambahkan heading dan jarak ke posisi semula. Hal ini terjadi,
karena kita tidak menghitung fungsi invers secara tepat, tetapi
mengambil perkiraan jari-jari bumi di sepanjang jalan.


\>sposprint(esadd(Tugu,esdir(Tugu,Monas),esdist(Tugu,Monas)))


    S 6°10.500' E 106°48.717'

Namun, kesalahannya tidak besar.


\>sposprint(Monas),


    S 6°10.500' E 106°48.717'

Tentu kita tidak bisa berlayar dengan tujuan yang sama dari satu
tujuan ke tujuan lainnya, jika kita ingin menempuh jalur terpendek.
Bayangkan, Anda terbang NE mulai dari titik mana pun di bumi. Kemudian
Anda akan berputar ke kutub utara. Lingkaran besar tidak mengikuti
heading yang konstan!


Perhitungan berikut menunjukkan bahwa kami jauh dari tujuan yang
benar, jika kami menggunakan pos yang sama selama perjalanan kami.


\>dist=esdist(Tugu,Monas); hd=esdir(Tugu,Monas);


Sekarang kita tambahkan 10 kali sepersepuluh dari jarak, menggunakan
pos ke Monas, kita sampai di Tugu.


\>p=Tugu; loop 1 to 10; p=esadd(p,hd,dist/10); end;


Hasilnya jauh.


\>sposprint(p), skmprint(esdist(p,Monas))


    S 6°11.250' E 106°48.372'
         1.529km

Sebagai contoh lain, mari kita ambil dua titik di bumi pada garis
lintang yang sama.


\>P1=[30°,10°]; P2=[30°,50°];


Jalur terpendek dari P1 ke P2 bukanlah lingkaran garis lintang 30°,
melainkan jalur terpendek yang dimulai 10° lebih jauh ke utara di P1.


\>sdegprint(esdir(P1,P2))


         79.69°

Tapi, jika kita mengikuti pembacaan kompas ini, kita akan berputar ke
kutub utara! Jadi kita harus menyesuaikan arah kita di sepanjang
jalan. Untuk tujuan kasar, kami menyesuaikannya pada 1/10 dari total
jarak.


\>p=P1;  dist=esdist(P1,P2); ...  
\>     loop 1 to 10; dir=esdir(p,P2); sdegprint(dir), p=esadd(p,dir,dist/10); end;


         79.69°
         81.67°
         83.71°
         85.78°
         87.89°
         90.00°
         92.12°
         94.22°
         96.29°
         98.33°

Jaraknya tidak tepat, karena kita akan menambahkan sedikit kesalahan,
jika kita mengikuti heading yang sama terlalu lama.


\>skmprint(esdist(p,P2))


         0.203km

Kami mendapatkan perkiraan yang baik, jika kami menyesuaikan pos
setelah setiap 1/100 dari total jarak dari Tugu ke Monas.


\>p=Tugu; dist=esdist(Tugu,Monas); ...  
\>     loop 1 to 100; p=esadd(p,esdir(p,Monas),dist/100); end;

\>skmprint(esdist(p,Monas))


         0.000km

Untuk keperluan navigasi, kita bisa mendapatkan urutan posisi GPS di
sepanjang lingkaran besar menuju Monas dengan fungsi navigasi.


\>load spherical; v=navigate(Tugu,Monas,10); ...  
\>     loop 1 to rows(v); sposprint(v[#]), end;


    S 7°46.998' E 110°21.966'
    S 7°37.422' E 110°0.573'
    S 7°27.829' E 109°39.196'
    S 7°18.219' E 109°17.834'
    S 7°8.592' E 108°56.488'
    S 6°58.948' E 108°35.157'
    S 6°49.289' E 108°13.841'
    S 6°39.614' E 107°52.539'
    S 6°29.924' E 107°31.251'
    S 6°20.219' E 107°9.977'
    S 6°10.500' E 106°48.717'

Kami menulis sebuah fungsi, yang memplot bumi, dua posisi, dan posisi
di antaranya.


\>function testplot ...


    useglobal;
    plotearth;
    plotpos(Tugu,"Tugu Jogja"); plotpos(Monas,"Tugu Monas");
    plotposline(v);
    endfunction
</pre>
Sekarang rencanakan semuanya.


\>plot3d("testplot",angle=25, height=6,\>own,\>user,zoom=4):


![images/Afifah%20Setyaningsih_23030630009_Geometri-292.png](images/Afifah%20Setyaningsih_23030630009_Geometri-292.png)

Atau gunakan plot3d untuk mendapatkan tampilan anaglyph. Ini terlihat
sangat bagus dengan kacamata merah/sian.


\>plot3d("testplot",angle=25,height=6,distance=5,own=1,anaglyph=1,zoom=4):


![images/Afifah%20Setyaningsih_23030630009_Geometri-293.png](images/Afifah%20Setyaningsih_23030630009_Geometri-293.png)

## Latihan

1. Gambarlah segitiga ABC dengan titik A = (4,4), B = (1,5), C = (4,0)
dan carilah spreed di B!


\>C&:=[4,0]; A&:=[4,4]; B&:=[1,5];

\>setPlotRange(-1,5,-1,5);

\>plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"); 

\>plotSegment(B,A,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"); 

\>insimg(30);


![images/Afifah%20Setyaningsih_23030630009_Geometri-294.png](images/Afifah%20Setyaningsih_23030630009_Geometri-294.png)

\>$distance(A,B)


$$\sqrt{10}$$\>c &= quad(A,B); $c, b &= quad(A,C); $b, a &= quad(B,C); $a, 


$$10$$$$16$$$$34$$\>wb &= computeAngle(A,B,C); $wb, $(wb/pi\*180)()


$$\arccos \left(\frac{14}{\sqrt{10}\,\sqrt{34}}\right)$$    40.601294645

\>$crosslaw(a,b,c,x), $solve(%,x),


$$64=640\,\left(1-x\right)$$$$\left[ x=\frac{9}{10} \right] $$\>sb &= spread(b,a,c); $sb


$$\frac{36}{85}$$2. Gambarlah segitiga ABC titiknya A = (3,5), B = (4,3) C = (2,1) lalu
carilah


a. jarak serta kuadrat jarak AB, AC, CB


b. tentukan sudut sudutnya menggunakan rumus cosinus


\>load geometry;

\>C&:=[2,1]; A&:=[3,5]; B&:=[4,3]; ...  
\>   setPlotRange(-1,5,-1,5); ...  
\>   plotPoint(A,"A"); plotPoint(B,"B"); plotPoint(C,"C"); ...  
\>   plotSegment(B,A,"c"); plotSegment(A,C,"b"); plotSegment(C,B,"a"); ...  
\>   insimg(30);


![images/Afifah%20Setyaningsih_23030630009_Geometri-303.png](images/Afifah%20Setyaningsih_23030630009_Geometri-303.png)

a. jarak serta kuadrat jarak AB, AC, CB


\>$distance(A,B)


$$\sqrt{5}$$\>$distance(A,C)


$$\sqrt{17}$$\>$distance(C,B)


$$2^{\frac{3}{2}}$$\>c &= quad(A,B); $c, b &= quad(A,C); $b, a &= quad(B,C); $a,


$$5$$$$17$$$$8$$b. menentukan sudut menggunakan rumus cosinus


\>wb &= computeAngle(A,B,C); $wb, $(wb/pi\*180)()


$$\pi-\arccos \left(\frac{1}{\sqrt{2}\,\sqrt{5}}\right)$$    108.434948823

\>wa &= computeAngle(B,A,C); $wa, $(wa/pi\*180)()


$$\arccos \left(\frac{7}{\sqrt{5}\,\sqrt{17}}\right)$$    40.601294645

\>wc &= computeAngle(A,C,B); $wc, $(wc/pi\*180)()


$$\arccos \left(\frac{5}{\sqrt{2}\,\sqrt{17}}\right)$$    30.9637565321

3. Gambarlah suatu parabola yang melalui 3 titik yang diketahui.


Petunjuk:


- Misalkan persamaan parabolanya y= ax^2+bx+c.


- Substitusikan koordinat titik-titik yang diketahui ke persamaan
tersebut.


- Selesaikan SPL yang terbentuk untuk mendapatkan nilai-nilai a, b, c.


\>load geometry;

\>setPlotRange(5); P=[2,0]; Q=[4,0]; R=[0,-4];

\>plotPoint(P,"P"); plotPoint(Q,"Q"); plotPoint(R,"R"):


![images/Afifah%20Setyaningsih_23030630009_Geometri-313.png](images/Afifah%20Setyaningsih_23030630009_Geometri-313.png)

\>sol &= solve([a+b=-c,16\*a+4\*b=-c,c=-4],[a,b,c])


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
    sol &amp;= solve([a+b=-c,16*a+4*b=-c,c=-4],[a,b,c]) ...
                                                   ^

\>function y&=-x^2+5\*x-4


    
                                   2
                                - x  + 5 x - 4
    

\>plot2d("-x^2+5\*x-4",-5,5,-5,5):


![images/Afifah%20Setyaningsih_23030630009_Geometri-314.png](images/Afifah%20Setyaningsih_23030630009_Geometri-314.png)

4. Gambarlah suatu ellips jika diketahui kedua titik fokusnya,
misalnya P dan Q. Ingat ellips dengan fokus P dan Q adalah tempat
kedudukan titik-titik yang jumlah jarak ke P dan ke Q selalu sama
(konstan).


Penyelesaian :


Diketahui kedua titik fokus P = [-1,-1] dan Q = [1,-1]


\>P=[-1,-1]; Q=[1,-1];

\>function d1(x,y):=sqrt((x-P[1])^2+(y-P[2])^2)

\>Q=[1,-1]; function d2(x,y):=sqrt((x-P[1])^2+(y-P[2])^2)+sqrt((x-Q[1])^2+(y-Q[2])^2)

\>fcontour("d2",xmin=-2,xmax=2,ymin=-3,ymax=1,hue=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-315.png](images/Afifah%20Setyaningsih_23030630009_Geometri-315.png)

Grafik yang lebih menarik


\>plot3d("d2",xmin=-2,xmax=2,ymin=-3,ymax=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-316.png](images/Afifah%20Setyaningsih_23030630009_Geometri-316.png)

Batasan ke garis PQ


\>plot2d("abs(x+1)+abs(x-1)",xmin=-3,xmax=3):


![images/Afifah%20Setyaningsih_23030630009_Geometri-317.png](images/Afifah%20Setyaningsih_23030630009_Geometri-317.png)

5. Gambarlah suatu hiperbola jika diketahui kedua titik fokusnya,
misalnya P dan Q. Ingat ellips dengan fokus P dan Q adalah tempat
kedudukan titik-titik yang selisih jarak ke P dan ke Q selalu sama
(konstan).


\>P=[-1,-1]; Q=[1,-1];

\>function d1(x,y):=sqrt((x-p[1])^2+(y-p[2])^2)

\>Q=[1,-1]; function d2(x,y):=sqrt((x-P[1])^2+(y-P[2])^2)+sqrt((x+Q[1])^2+(y+Q[2])^2)

\>fcontour("d2",xmin=-2,xmax=2,ymin=-3,ymax=1,hue=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-318.png](images/Afifah%20Setyaningsih_23030630009_Geometri-318.png)

\>plot3d("d2",xmin=-2,xmax=2,ymin=-3,ymax=1):


![images/Afifah%20Setyaningsih_23030630009_Geometri-319.png](images/Afifah%20Setyaningsih_23030630009_Geometri-319.png)

\>plot2d("abs(x+1)+abs(x-1)",xmin=-3,xmax=3):


![images/Afifah%20Setyaningsih_23030630009_Geometri-320.png](images/Afifah%20Setyaningsih_23030630009_Geometri-320.png)

